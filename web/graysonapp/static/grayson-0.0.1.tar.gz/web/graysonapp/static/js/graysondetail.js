
function GraysonDetail () {
    this.events = [];
    this.eventCount = 0;    
    $("#detail_view").resizable ({
	    handles   : 'n',
	    maxHeight : 1000,
	    minHeight : 120 /*,
	    stop      : function (event, ui) {
		var button = $(".detailpanel-btn-slide");
		button.css ({ top : "" + $(window).height () - $(ui).height - button.height ()});
	    }
			    */
    });
    $("#detailTabs").tabs ({	    
	    show: function (event, ui) {
		if (ui.panel.id == 'compute_detail') {
		    //$("#compute_graph").html ("");
		    //grayson.detailView.graphCompute ();
		}
	    }
	});

    $("#compute_detail").resize (function () {
	    //$("#compute_graph").html ("");
	    //grayson.detailView.graphCompute ();
	});

    /*
    $(".detailpanel-btn-slide").click (function (event){
	    var height = Math.min ( $("#detail_view").height (), 500);
	    var top = $(window).height () - height;
	    $('#detail_view').css ({
		    position   : "absolute",
		    bottom : "0px",
		    top    : top + "px",
			//height : height + "px",
		    width  : "100%"
	    });
	    $("#detail_view").fadeToggle ('slow');
	    $(this).toggleClass("detailpanel-active");

	    $("#eventTable").dataTable ({
		    bDestroy        : true,
		    bJQueryUI       : true,
		    sPaginationType : "full_numbers"
	    }).css ({
		    width : "100%"
	    });

	    $("#networkTable").dataTable ({
		    bDestroy        : true,
		    bJQueryUI       : true,
		    sPaginationType : "full_numbers"
	    }).css ({
		    width : "100%"
	    });

	    return false;
	});
    */
    $(window).resize (function() {
	    var height = $("#detail_view").height ();
	    var top = $(window).height () - height;
	    $('#detail_view').css ({
		    position : "absolute",
		    bottom : "0px",
		    top    : top + "px",
		    height : height + "px",
		    width  : "100%"
	    });
	});
};
GraysonDetail.prototype.toggle = function () {
    var height = Math.min ( $("#detail_view").height (), 500);
    var top = $(window).height () - height;
    $('#detail_view').css ({
	    position   : "absolute",
		bottom : "0px",
		top    : top + "px",
		width  : "100%"
		});
    $("#detail_view").fadeToggle ('slow');
    $("#eventTable").dataTable ({
	    bDestroy        : true,
		bJQueryUI       : true,
		sPaginationType : "full_numbers"
		}).css ({
			width : "100%"
			    });    
    $("#networkTable").dataTable ({
	    bDestroy        : true,
		bJQueryUI       : true,
		sPaginationType : "full_numbers"
		}).css ({
			width : "100%"
			    });
    
};
GraysonDetail.prototype.hide = function () {
    $(".detailpanel-btn-slide").removeClass ("detailpanel-active");
    $("#detail_view").hide ();
};
GraysonDetail.prototype.initialize = function (e) {
    $("#eventList").html ('');
    $("#networkEventList").html ('');
    $("#dax_detail").html ('');
    $("#submit_detail").html ('');
};

GraysonDetail.prototype.addEvent = function (e) {
    var type = e.event.type;
    if (type == "endEventStream") {
	var target = basename (e.workflowId);
	var value = "";
	var status = "";
	var time = new Date ();
	var workdir = "";
	var html = [];
	var networkEvents = [];
	var event = null;

	for (var c = 0; c < this.events.length; c++) {
	    event = this.events [c];
	    type = event.event.type;
	    if (type == "jobstatus") {
		target = event.event.job;
		value  = event.event.state;
		time.setTime (event.event.time * 1000);
		workdir = event.event.logdir;
	    } else if (type == "workflow.structure") {
		target = event.event.element;
		value = "";
		time.setTime (0);
		workdir = "";
	    }
	    html.push ( '<tr>',
			'   <td>', time, '</td>',
			'   <td>', type, '</td>',
			'   <td nowrap="true">',
			'      <div path="', workdir, '" resource="', target, '">', target,
			/*
			'         <div class="linkToCompute" >Compute</div>',
			*/
			'         <div class="linkToDax"     >DAX</div>',
			'         <div class="linkToCondor"  >Condor</div>',
			'      </div>',
			'   </td>',
			'   <td>', value, '</td>',
			'   <td>order: ', this.eventCount, '</td>',
			'</tr>' );

	    
	    if (target.startsWith ("stage_in_") || target.startsWith ("stage_out_")) {
		networkEvents.push (event);
	    }

	    this.eventCount++;
	}
	$("#eventList").html ( $( html.join ('') ) );

	$(".linkToCondor").click (function (event) {
		var path = $(this).parent().attr ("path");
		var pattern = grayson.detailView.getPattern (path);
		grayson.api.get (grayson.api.formJobOutputURL (pattern + "/" + $(this).parent().attr ("resource") + ".sub"),
				 function (text) {
				     var html = [ '<textarea id="submit_detail_text" rows="25" class="editorPane" >',
						  text,
						  '</textarea>',
						  '<button id="save_submit_detail">Save</button><p>(Not Implemented)</p>' ].join ("");
				     $("#submit_detail").html (html);
				     $("#detailTabs").tabs ('select', "#submit_detail");
				     $("#save_submit_detail").click (function (event) {
					     grayson.log_info ("saving " + $("#submit_detail_text").html ());
					 });
				 });
	    });	
	$(".linkToDax").click (function (event) {
		var path = $(this).parent().attr ("path");
		var pattern = grayson.detailView.getPattern (path);
		var base = basename (path);
		index = base.indexOf ("_");
		if (index > -1) {
		    grayson.api.get (grayson.api.formJobOutputURL (pattern + ".dax"),
				     function (text) {
					 var html = [ '<textarea id="dax_detail_text" rows="35" class="editorPane" >',
						      text,
						      '</textarea>',
						      '<button id="save_dax_detail" path="', path, '" >Save</button>' ].join ('');
					 $("#dax_detail").html (html);
					 $("#detailTabs").tabs ('select', "#dax_detail");
					 $("#save_dax_detail").click (function (event) {
						 grayson.log_info ("saving " + $("#dax_detail_text").html ());
					     });
				     });
		}
	});
	grayson.api.getNetworkProfile (function (response) {
		var html = [];
		var item = null;
		var protocol = null;
		var protocolRe = new RegExp ("[a-zA-Z]+://");
		for (var c = 0; c < response.length; c++) {
		    item = response [c];
		    srcProtocol = protocolRe.exec (item.sourcePath);
		    dstProtocol = protocolRe.exec (item.destinationPath);
		    html.push ( '<tr>',
				'   <td title="', item.sourcePath, '">', basename(item.sourcePath), ' @ ', item.sourceSite.substring (1), '</td>',
				'   <td title="', item.destinationPath, '">', basename(item.destinationPath), ' @ ', item.destinationSite.substring (1), '</td>',
				'   <td>', srcProtocol, ' -> ', dstProtocol, '</td>',
				'   <td>N/A</td>',
				'   <td>', item.size, '</td>',
				'   <td>', item.time, '</td>',
				'   <td>', item.down, '</td>',
				'   <td>', item.up, '</td>',
				'</tr>' );
		}
		$("#networkEventList").html ( html.join ('') );
	    });
	$("#networkTable").dataTable ({
		bDestroy        : true,
		bJQueryUI       : true,
	        sPaginationType : "full_numbers"
        }).css ({
		width : "100%"
	});

	$("#eventTable").dataTable ({
		bDestroy        : true,
		bJQueryUI       : true,
		sPaginationType : "full_numbers"
	}).css ({
	        width : "100%"
	});
	grayson.api.progressMinus ();
    } else {
	this.events.push (e);
    }


};

GraysonDetail.prototype.getPattern = function (path) {
    var pattern = null;
    var runId = grayson.api.getFlowContext().runId;
    var index = path.indexOf (runId);
    if (index > -1) {
	pattern = path.substring (index + runId.length).substring (1);
    }
    return pattern;
};

GraysonDetail.prototype.graphCompute = function () {

    // For horizontal bar charts, x an y values must will be "flipped"
    // from their vertical bar counterpart.
    var plot2 = $.jqplot('compute_graph', [
        [[2,1], [4,2], [6,3], [3,4]], 
        [[5,1], [1,2], [3,3], [4,4]], 
        [[4,1], [7,2], [1,3], [2,4]]], {
        seriesDefaults: {
            renderer:$.jqplot.BarRenderer,
            // Show point labels to the right ('e'ast) of each bar.
            // edgeTolerance of -15 allows labels flow outside the grid
            // up to 15 pixels.  If they flow out more than that, they 
            // will be hidden.
            pointLabels: { show: true, location: 'e', edgeTolerance: -15 },
            // Rotate the bar shadow as if bar is lit from top right.
            shadowAngle: 135,
            // Here's where we tell the chart it is oriented horizontally.
            rendererOptions: {
                barDirection: 'horizontal'
            }
        },
        axes: {
            yaxis: {
                renderer: $.jqplot.CategoryAxisRenderer
            }
        }
    });

};
