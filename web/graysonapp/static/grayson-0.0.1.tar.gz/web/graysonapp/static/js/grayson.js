var grayson = null;

/*
===============================
==    J A V A S C R I P T    ==
===============================
*/
String.prototype.startsWith = function (str){
    return this.slice(0, str.length) == str;
};

/*
===============================
==    J Q U E R Y            ==
===============================
*/
$.fn.exists = function () { return $(this).length > 0; };

/*
===============================
==     S O C K E T . I O     ==
=============================== */
var socket = new io.connect (null,
			     {
				 port : graysonConf.socketioListenPort
			     });
socket.on ('message', function (eventText) {
	grayson.log_debug (eventText);
	grayson.api.progressPlus ();
	try {
	    var message = $.parseJSON (eventText);
	    if (message.args) {
		for (var c = 0; c < message.args.length; c++) {
		    grayson.handleEvent (message.args [c]);
		}
	    } else {
		grayson.handleEvent (message);
	    }
	} catch (e) {
	    grayson.log_error ('exception: ' + e.message);
	}
	grayson.api.progressMinus ();
    });
socket.on ('connect', function () {
	setConnectStatus ("Connected.");
	socket.emit ('subscribe', '{ "subscribe" : "on", "clientId" : "' + graysonConf.clientId + '" }');
	setTimeout ("setConnectStatus ('')", 3000);
    });
socket.on('disconnect', function() {
	setConnectStatus ("Disconnected.");
    });
socket.on('reconnect',  function() {
	setConnectStatus ("Reconnected");
    });
socket.on('reconnecting', function( nextRetry ){
	setConnectStatus ("Re-connect in " + nextRetry + "ms");
    });
socket.on('reconnect_failed', function(){
	setConnectStatus ("Reconnected failed.");
    });
function setConnectStatus (msg) {
    display = $("#status");
    if (msg == '') {
	display.hide ('slow');
    } else {
	display.show ('slow');
	display.html (msg);
    }
};

/*
=========================================
==      G R A Y S O N   G R A P H      ==
=========================================
*/
function GraysonGraph () {
    this.graph = [];
    this.nodeMap = {};
    this.labelMap = {};
}
GraysonGraph.prototype.mapNode = function (node) {
    this.nodeMap[node.id] = node;
    this.labelMap[node.label.text] = node;
    this.graph.push (node);
};
GraysonGraph.prototype.getNode = function (nodeId) {
    return this.labelMap [nodeId];
};
GraysonGraph.prototype.toString = function () {
    return ("\n   " + this.graph + 
	    "\n   " + this.nodeMap + 
	    "\n   " + this.labelMap);
};

/*
===============================
==  G R A Y S O N  T A B S   ==
===============================
*/
function GraysonTabs () {
    this.elementId = "#tabs";
    this.tabId = 0;
}

GraysonTabs.prototype.initialize = function () {
    if ($(this.elementId).exists ())
	$(this.elementId).remove ();
    $("body").append ($( '<div id="tabs" class="workflowTabs"><ul id="tab-labels"></ul></div>' ));
    $(this.elementId).tabs ();
};

GraysonTabs.prototype.addTab = function (name) {
    var id = ++this.tabId;
    var tabDivId = "tabs-" + id
    var labelId = "g" + id
    var drawdivId = "drawdiv" + id
    var tabId = "#" + tabDivId;
    $tabs = $(this.elementId).tabs ("add", tabId, name).tabs ({
	    add: function (event, ui) {
		$tabs.tabs('select', '#' + ui.panel.id);
	    }
	});
    $(tabId).css ("display","block");
    $(tabId).attr ("graphname", name);
    var drawdiv = $('<div id="' + drawdivId + '" class="drawdiv"></div>');
    $(tabId).append (drawdiv);
    $tabs.tabs('select', id);
    return drawdivId
};

GraysonTabs.prototype.selectTab = function (indexOrId) {
    $(this.elementId).tabs('select', indexOrId);
};

/*
===============================
==  G R A Y S O N   A P I    ==
===============================
*/
function GraysonAPI (grayson) {
    this.grayson = grayson;
    this.progress = 0;
    this.flowContext = {
	workdir    : null,
	workflowId : null,
	runId      : null
    };
};
GraysonAPI.prototype.localizeURI = function (uri) {
    var prefix = graysonConf.uriPrefix;
    return prefix == '/' ? prefix + uri : prefix + '/' + uri;
};
GraysonAPI.prototype.setFlowContext = function (context) {
    this.flowContext = context;
};
GraysonAPI.prototype.getFlowContext = function () {
    return this.flowContext;
};
GraysonAPI.prototype.formJobOutputURL = function (pattern) {
    return this.formJobOutputURI (this.flowContext.workdir,
				  basename (this.flowContext.workflowId).replace (".dax", ""),
				  this.flowContext.runId,
				  pattern);
};
GraysonAPI.prototype.formJobResourceArgs = function (workdir, workflowid, runid, jobid) {
    var args = [ "?workdir="     , workdir,
		 "&workflowid="  , workflowid,
		 "&runid="       , runid ];
    if (jobid) {
	args.push ("&jobid="     , jobid);
    }
    return args.join ("");
};
GraysonAPI.prototype.getNetworkProfile = function (success) {
    var flowContext = this.getFlowContext (); 
    var uri = [ "get_network_profile",
		"?workdir="     , flowContext.workdir,
		"&workflowid="  , basename(flowContext.workflowId).replace (".dax", ""),
		"&runid="       , flowContext.runId ]
    .join ("");
    this.getJSON (uri, success);
};
GraysonAPI.prototype.formJobOutputURI = function (workdir, workflowid, runid, jobid) {
    return [ "get_job_output",
	     this.formJobResourceArgs (workdir, workflowid, runid, jobid) ].join ('');
};
GraysonAPI.prototype.progressPlus = function () {
    this.progress++;
    if (this.progress > 0) {
	$("#ajax-loader").show (); //'slow');
    }
};
GraysonAPI.prototype.progressMinus = function () {
    this.progress--;
    if (this.progress <= 0) {
	this.progress = 0;
	$("#ajax-loader").hide (); //'slow');
    }
};
GraysonAPI.prototype.getJSON = function (url, success, error) {
    this.ajax (url,	       
	      function (text) {
		  if (text) {
		      var response = grayson.api.parseJSON (text);// $.parseJSON (text);
		      if (response) {
			  success (response);
		      }
		  }
	      },
	      error);

};
GraysonAPI.prototype.getXML = function (url, success, error) {
    this.ajax (url, success, error, 'xml');
};
GraysonAPI.prototype.postJSON = function (url, data, success, error) {
    this.post (url,
	       data,
	       function (text) {
		   if (text) {
		       var response = grayson.api.parseJSON (text);
		       if (response) {
			   success (response);
		       }
		   }
	       },
	       error);
};
GraysonAPI.prototype.parseJSON = function (text) {
    var object = null;
    if (text) {
	var response = $.parseJSON (text);
	if (response) {
	    if (response.status && response.status === 'login_required') {
		$("#loginDialog").dialog ('open');
	    } else {
		object = response;
	    }
	}
    }    
    return object;
};
GraysonAPI.prototype.post = function (url, data, success, error, mimeType, method) {
    this.ajax (url, success, error, mimeType, "POST", data);
};
GraysonAPI.prototype.get = function (url, success, error, mimeType, method) {
    this.ajax (url, success, error, mimeType);
};
GraysonAPI.prototype.ajax = function (url, success, error, mimeType, method, data) {
    this.progressPlus ();
    var api = this;

    if (typeof (mimeType) !== 'string') {
	mimeType = "text";
    }
    if (typeof (method) !== 'string') {
	method = "GET";
    }
    var args = {
	    type     : method,
	    url      : this.localizeURI (url), 
	    dataType : mimeType,
	    success: function (text) {
       	        if (typeof (text) === 'string' && text.indexOf ("login_required") > -1) {
		    $("#loginDialog").dialog ('open');
		} else {
		    success (text);
		}
	    },
	    error: function (jqXHR, textStatus, errorThrown) {
		if (error) {
		    error (textStatus, errorThrown);
		} else {
		    grayson.log_error ("error: " + textStatus + " error: " + errorThrown);
		}
	    },
	    complete : function (jqXHR, textStatus) {
		api.progressMinus ();
	    }
    };

    if (typeof (data) === 'object') {
	args ['data'] = data;
	if (!safeMethod (method) && sameOrigin (url)) {
	    data ['csrfmiddlewaretoken'] = getCookie ('csrftoken');
	}
    }

    $.ajax (args);
};

/*
===============================
==     K I C K S T A R T     ==
===============================
*/
function GraysonKickstart (text) {
    this.valid = false;
    if (text && text.startsWith ("<?xml")) {
	xml = $.parseXML (text);
	this.invocation = $(xml).find ("invocation");
	this.resource = this.invocation.attr ("resource");
	this.hostname = this.invocation.attr ("hostname");
	this.start = this.invocation.attr ("start");
	this.duration = this.invocation.attr ("duration");
	this.user = this.invocation.attr ("user");
	this.job = this.invocation.attr ("transformation");
	this.exitcode = $(xml).find ("regular").attr ('exitcode');
	this.stdout = $(xml).find ('statcall[id="stdout"]').find ("data").text ();
	this.stderr = $(xml).find ('statcall[id="stderr"]').find ("data").text ();
	this.valid = true;
    }
};


/*
===============================
==      G R A Y S O N        ==
===============================
*/
function Grayson (args) {
    this.api = new GraysonAPI ();
    this.callbacks = {};
    this.tabs = new GraysonTabs ();
    this.detailView = new GraysonDetail (this);
    this.selectedWorkflow = null;
    this.initialize ();

    if (args && args.handlers) {
	for (var c = 0; c < args.handlers.length; c++) {
	    var handler = args.handlers [c];
	    if (handler) {
		this.register (handler.key, handler.callback);
	    }
	}
    }
};

Grayson.prototype.initialize = function () {
    this.graphs = {};
    this.subworkflowEvents = [];
    this.context = {};
    this.clientId = null;

    this.detailView.initialize ();
    $(".tooltip").remove ();
};
Grayson.prototype.prepareCanvas = function () {
    this.initialize ();
    this.tabs.initialize ();
    $("#about").hide ();
};




Grayson.prototype.byId = function (graphId, id) {
    for (w in self.graphs) {
	grayson.log_debug ("    graph: " + self.graphs [graphId]);
    }
    return this.graphs[graphId].nodeMap [id];
};

Grayson.prototype.getGraph = function (graphId) {
    grayson.log_debug ("grayson:_getGraph: " + graphId)
    return this.graphs [graphId].graph;
}

Grayson.prototype.register = function (eventType, callback) {
    for (k in this.callbacks) {
	this.log_debug (" -- " + k + " => " + this.callbacks [k]);
    }
    this.callbacks [eventType] = callback;
};

Grayson.prototype.mapNode = function (graphId, node) {
    grayson.log_debug ("grayson:_mapNode: graphId: " + graphId + " node: " + node);
    if (graphId in this.graphs) {
    } else {
	this.graphs [graphId] = new GraysonGraph ();
	grayson.log_debug ("grayson:_initialized: graphId: " + graphId);
    }
    var graph = this.graphs [graphId];
    if (graph) {
	this.graphs[graphId].mapNode (node);
    }
};

Grayson.prototype.getNode = function (workflowId, nodeId) {
    var node = null;
    if (workflowId in this.graphs) {
	var graph = this.graphs [workflowId];
	if (graph) {
	    node = graph.getNode (nodeId);
	}
    }
    return (node);
};

Grayson.prototype.send = function (data) {
    socket.send (data);
};

Grayson.prototype.handleEvent = function (event) {
    this.log_debug ("grayson:event:event [" + event.event.type + "]");
    
    eventType = event.event.type;
    text = JSON.stringify (event);
    callback = this.callbacks [eventType]
    this.detailView.addEvent (event);
    if (callback) {
	try {
	    callback (event);
	} catch (e) {
	    this.log_error ("grayson:event:eventType [" + eventType + 
			    "] callback produced exception: [" + e.message + 
			    "] for event: " + event);
	}
    } else {
	grayson.log_debug ("grayson:event:no-handler: event: " + eventType);
    }
};

Grayson.prototype.log_info = function (m) {
    if (window.console && console.log) {
	console.log (m);
    }
};

Grayson.prototype.log_debug = function (m) {
    if (window.console && console.log) {
	console.debug (m);
    }
};

Grayson.prototype.log_error = function (m) {
    if (window.console && console.log) {
	console.error (m);
    }
};

Grayson.prototype.post = function (uri, handler) {
    $.post (uri,
	    function (data) {
		try {
		    object = $.parseJSON (data);
		    handler (object);
		} catch (e) {
		    alert (e.name + " " + e.message)
		}
	    });
};

Grayson.prototype.getBaseId = function (name) {
    var value = null;
    if (name) {
	var parts = name.split (".");
	value = parts [0];
    }
    return value;
};

Grayson.prototype.getNormalizedNodeName = function (name) {
    if (name !== null && name.startsWith ("subdax_")) {
	name = name.split ("_")[1];
	name = this.getBaseId (name);
	var id = parts [1]
    } else if (name.indexOf ("_") > -1) {
	name = name.substring (0,
			       name.lastIndexOf ("_"));
    }
    return name;
};

Grayson.prototype.onUpdateJobStatus = function (event) {

    var colorMap = {
	"pending"   : '#06f',  // blue
	"executing" : '#ff3',  // yellow
	"failed"    : '#f00',  // red
	"succeeded" : '#3f0',  // green
	"1"         : '#ff0',  // red
	"0"         : '#3f0'   // green
    };
    var name = event.event.job;
    if (event.event != null && name != null) {
	var state = event.event.state;
	var jobName = null;
	var jobId = null;
	var instanceId = null;
	if (name !== null && name.startsWith ("subdax_")) { // subdax_slice.2_ID0000003
	    var parts = name.split ("_");
	    name = parts [1];
	    jobId = parts [ parts.length - 1 ];
	    
	    parts = name.split (".");
	    jobName = parts [0];
	    instanceId = parts [1];
	} else if (name.indexOf ("_") > -1) { // padcswan_n1
	    var index = name.lastIndexOf ("_");
	    jobName = name.substring (0, name.lastIndexOf ("_"));
	    jobId = name.substring (index + 1);
	} else {
	    jobName = name;
	}
	if (jobName && state in colorMap) {
	    var node = this.getNode (event.workflowId, jobName);
	    var color = colorMap [state];
	    if (instanceId == null) {
		if (node && node.graphNode) {
		    if (state == 'running' || state == 'pending') {
			node.graphNode.animate ({
				stroke             : color,
				    opacity        : 0.7,
				    'stroke-width' : 4,
				    title          : 'job status: ' + state
				    }, 50);
		    } else {
			node.graphNode.animate ({
				stroke             : color,
				    opacity        : 1,
				    'stroke-width' : 4,
				    title          : 'job status: ' + state
				    }, 50);
		    }
		}
	    } else if (jobId) {
		this.showFlowSelector (null, node);
		var instanceSelector = "#" + node.id + "_" + instanceId;
		var instance = $(instanceSelector);
		if (instance != null) {
		    instance.css ({ "background-color" : color });
		}
	    }
	}
    }
};

Grayson.prototype.processSubworkflows = function (workflow) {
    grayson.log_debug ("grayson:process-subworkflows: ");
    processedSubworkflows = [];
    for (var c = 0; c < grayson.subworkflowEvents.length; c++) {
	var event = grayson.subworkflowEvents [c];
	var node = grayson.getNode (workflow, event.event.element);
	if (node) {
	    node.instances.push (event.workflowId);
	    this.addFlowInstance (workflow, node, event.workflowId);
	    if (node.selectedInstance == null) {
		node.selectedInstance = event.workflowId;
		this.setContext (node.label.text, event.workflowId);
	    }
	    if (node.annot.type == 'workflow' && $.inArray (event.event.element, processedSubworkflows) ) {
		graphPath = dirname (event.workflowId) + "/" + event.event.element + ".graphml";
		this.onRenderWorkflow (event.workflowId, graphPath);
		processedSubworkflows.push (event.event.element);
	    }
	}		
    }
};

Grayson.prototype.getContextInstance = function () {
    return this.context [this.selectedWorkflow];
};

Grayson.prototype.setContext = function (workflowNodeName, instance) {
    grayson.log_debug ("grayson:set-context: wf:" + workflowNodeName + ", instance:: " + instance);
    this.context [workflowNodeName] = instance;
};

Grayson.prototype.selectWorkflow = function (graphName) {
    var tab = $('[graphname="' + graphName + '.graphml"]');
    var id = tab.id;
    if (tab.length > -1) {
	tab = tab [0];
	id = tab.id;
    }
    this.tabs.selectTab (tab.id);
    this.selectedWorkflow = graphName;
};

Grayson.prototype.getInstanceId = function (instance) {
    var result = null;
    if (instance) {
	var parts = instance.split (".");
	result = parts [ parts.length - 2 ];
    }
    return result;
};

Grayson.prototype.addFlowInstance = function (workflow, node, instance) {

    var after = 0;
    var before = 0;

    // keep it sorted
    node.instances.sort (function (L, R) {
	    var L_id = parseInt (grayson.getInstanceId (L));
	    var R_id = parseInt (grayson.getInstanceId (R));
	    return L_id - R_id;
	});

    var instanceText = [];
    var containerSelector = "#" + node.id + "_instances";
    $(containerSelector).html ("");

    for (var c = 0; c < node.instances.length; c++) {
	var instance = node.instances [c];
	var instanceNumber = parseInt (grayson.getInstanceId (instance));
	var id = node.id + '_' + instanceNumber;
	var base = basename (instance);
	instanceText.push ('<div class="instanceSelector" id="' + id + '" instanceNumber="' + instanceNumber + '" ',
			   '     value="' + base + '"',
			   '     title="' + base + '">',
			   '</div>');
    }

    var text = instanceText.join ("");
    $(containerSelector).append ( $(text) );

    $(containerSelector + " > .instanceSelector").click (function (e) {
				      var value = $(this).attr ("value");
				      if ( $(this).hasClass ("selectedItem") ) {
					  var workflowId = value.replace (".dax", "");
					  var jobName = basename (value);

					  var url = grayson.api.formJobOutputURL (workflowId + '.*?.dagman.out');
					  var jobStatusLogURL = grayson.api.formJobOutputURL (workflowId + ".*?jobstate.log");

					  grayson.showJobOutput (grayson.api.getFlowContext().workflowId, jobName, "", url, jobStatusLogURL);
				      } else {
					  grayson.setContext (node.label.text, value);
					  $(".instanceSelector").removeClass ("selectedItem");
					  $(this).addClass ("selectedItem");
				      }
				  })
    .hover (function (e) {
		var length = 30;
		var name = basename ($(this).attr ("value"));
		name = name.substring (0, Math.min (length, name.length));
		$("#" + node.id + "_prev").html (basename ($(this).attr ("value")));
	    },
	    function (e) {
	    });
};

Grayson.prototype.createFlowSelector = function (workflow, node) {
    if (node && ( ! $("#" + node.id + "_tip").exists () ) ) {
	$("body").append ( ['<div class="tooltip" id="' + node.id + '_tip"> ',
			    '   <div class="instanceSelectorContainer"> ',
			    '      <div class="instanceSelectorLabel">Select an instance to steer:',
			    '         <div class="instanceSelectorItemName" id="' + node.id + '_prev">',
			    '         </div>',
			    '      </div>',
			    '      <div class="instanceSelectors" id="' + node.id + '_instances"></div>', 
			    '	</div>',
			    '</div>' ].join ("\n"));
    }
};

Grayson.prototype.showFlowSelector = function (workflow, node) {
    if (node && node.instances.length > 0) {
	var selectorId = "#" + node.id + "_tip";
	$("#" + node.id).tooltip ({
		tip : "#" + node.id + "_tip",
		    delay    : 60,
		    position : "top right",
		    offset   : [ 15, -140 ],
		    effect   : 'fade'
		    });
    }
};

Grayson.prototype.createFlowSelectors = function (workflow) {
    var graph = this.getGraph (workflow);
    if (graph) {
	for (var c = 0; c < graph.length; c++) {
	    node = graph [c];
	    this.createFlowSelector (workflow, node);
	}
    }
};

Grayson.prototype.createConnections = function (graph, paths, paper) {
    for (var n = 0; n < graph.length; n++) {
	var node = graph [n];
	var connections = [];
	for (var c = 0; c < paths.length; c++) {
	    var path = paths [c];
	    var source = null;
	    var target = null;
	    if (path.source && path.target) {
		if (path.source.id == node.id || path.target.id == node.id) {
		    if (path.source.id == node.id) {
			source = node;
			target = path.target;
		    } else if (path.target.id == node.id) {
			source = node;
			target = path.target;
		    }
		    if (source && target && (source != target)) {
			var connection = paper.connection (source.graphNode,
							   target.graphNode,
							   null,
							   "#9a9|2");
			connection.line.toBack ().toBack ();
			connections = paper ["connections"];
			connections.push (connection);
		    }
		}
	    }
	}
    }
};

Grayson.prototype.renderGraphNodes = function (workflow, paper) {
    var graph = this.getGraph (workflow);
    if (graph) {
	var minX = 0;
	var minY = 0;
	for (var c = 0; c < graph.length; c++) {
	    node = graph [c];
	    if (node.geom.x < minX)
		minX = node.geom.x;
	    if (node.geom.y < minY)
		minY = node.geom.y;
	}
	var marginX = 10;
	var marginY = 10;
	for (var c = 0; c < graph.length; c++) {
	    node = graph [c];
	    node.geom.x = node.geom.x - minX + marginY;
	    node.geom.y = node.geom.y - minY + marginY;
	    nodeAttrs = {
		id             : node.id,
		fill           : node.fill,
		stroke         : "#366",
		r              : "3px",
		cursor         : "move",
		connections    : []
	    };
	    if (node.instances.length > 0)
		nodeAttrs["class"] = "overlay-class";

	    var rectangle = null;
	    var width = 0;
	    var height = 0;
	    if (node.shape == 'ellipse') {
		width = node.geom.width / 2;
		height = node.geom.height / 2;
		rectangle = paper.ellipse (node.geom.x + width, node.geom.y + height, width, height).attr (nodeAttrs).toBack (); //.draggable.enable ();
	    } else {
		rectangle = paper.rect (node.geom.x, node.geom.y, node.geom.width, node.geom.height).attr (nodeAttrs).toBack (); //.draggable.enable ();
	    }
	    var textSize = 10;
	    // unfortunate: render the text box to get its dimensions to calculate centering.
	    var text = paper.text (0, 0, node.label.text).toFront ().attr (node.label.style);
	    textWidth = text.getBBox().width;
	    textHeight = text.getBBox().height;
	    var textX = node.geom.x + ( (node.geom.width / 2) - (textWidth / 2));
	    var textY = node.geom.y + ( (node.geom.height / 2) - (textHeight / 8));
	    text.remove ();
	    var text = paper.text (textX, textY, node.label.text).toFront ().attr (node.label.style);

	    var set = paper.set ();
	    //set.draggable.enable ();
	    set.push (rectangle, text);
	    node.graphNode = rectangle;
	    rectangle.node.id = node.id;

	    if (node && node.annot && node.annot.type == 'workflow') {
		//rectangle.node.className += "overlay-class";
		//$(rectangle.node).addClass ("overlay-class");
	    }
	    $(rectangle.node).hover (function (e) {
		    node = grayson.byId (workflow, this.id);
		    //grayson.renderWorkflowSelector (workflow, node);
		    grayson.showFlowSelector (workflow, node);
		});
	    $(rectangle.node).click (function (e) {
		    node = grayson.byId (workflow, this.id);
		    if (node.annot.type == 'workflow') {
			grayson.selectWorkflow (node.label.text);
		    } else if (node.annot.type == 'job') {
			var jobWorkflowId = grayson.getContextInstance ();
			var jobName = node.label.text;
			var workdir = dirname (workflow) + "/work";
			var jobOutputURL = grayson.api.formJobOutputURL (jobName + "_.*?.out.000");
			var dagOutputURL = grayson.api.formJobOutputURL (jobName + ".*?.dagman.out");
			var jobStatusLogURL = grayson.api.formJobOutputURL (jobWorkflowId.replace (".dax", "") + ".*?jobstate.log");
			grayson.api.get (jobOutputURL, function (text) {
				grayson.showJobOutput (jobWorkflowId, node.label.text, text, dagOutputURL, jobStatusLogURL);
			    });
		    }
		});
	}
    }
};

Grayson.prototype.showJobOutput = function (workflowId, nodeName, text, dagOutputURL, jobStatusLogURL) {    
    // if ! workflowId need to select workflow.

    grayson.log_debug ("grayson:got job output for wf:" + workflowId + ", jobid:" + nodeName);
    var globalNewline = new RegExp("\n", 'g');
    var jobOutput = $("#jobOutputDialog");
    var html = [];
    jobOutput.html ("");
    jobOutput.dialog ('option', 'title', "Status for workflow: [" + basename(workflowId) + "], job: [" + nodeName + "]");
    var error = "";
    var output = "";

    var kickstart = new GraysonKickstart (text);
    if (kickstart.valid) {
	output = kickstart.stdout.replace (globalNewline, "<br/>");
	error = kickstart.stderr.replace (globalNewline, "<br/>");
    }
    // Build Tabs
    html.push ('  <div id="outputTabs" class="outputTabSet">',
	       '    <ul>');
    
    if (kickstart.valid) {
	html.push ('      <li><a href="#general">General</a></li>',
		   '      <li><a href="#output">Output</a></li>',
		   '      <li><a href="#error">Error</a></li>');
    }
    html.push ('      <li><a href="#DAG">Workflow Log</a></li>',
	       '      <li><a href="#jobStatusLog">Job Status Log</a></li>',
	       '    </ul>');
    
    if (kickstart.valid) {
	html.push ('    <div id="general" class="jobOutputTab">',
		   '      <table style="margins:0">',
		   '        <tr><td class="jobInfo">resource</td><td>', kickstart.resource, '</td></tr>',
		   '        <tr><td class="jobInfo">hostname</td><td>', kickstart.hostname, '</td></tr>',
		   '        <tr><td class="jobInfo">user</td><td>', kickstart.user, '</td></tr>',
		   '        <tr><td class="jobInfo">job</td><td>', kickstart.job, '</td></tr>',
		   '        <tr><td class="jobInfo">exitcode</td><td>', kickstart.exitcode, '</td></tr>',
		   '        <tr><td class="jobInfo">start</td><td>', kickstart.start, '</td></tr>',
		   '        <tr><td class="jobInfo">duration</td><td>', kickstart.duration, '</td></tr>',
		   '      </table>',
		   '    </div>',
		   '    <div id="output" class="jobOutputTab">',
		   output,
		   '    </div>',
		   '    <div id="error" class="jobOutputTab">',
		   error,
		   '    </div>');
    }

    html.push ('    <div id="DAG" class="jobOutputTab">',
	       '    </div>',
	       '    <div id="jobStatusLog" class="jobOutputTab">',
	       '    </div>',
	       '  </div>');

    jobOutput.html (html.join (""));
    $("#outputTabs").tabs ();


    // DAG output
    this.api.get (dagOutputURL,  function (text) {
	    $("#DAG").html (text.replace (globalNewline, "<br/>"));
	});
    
    // Job Status Log
    this.api.get (jobStatusLogURL,  function (text) {
	    $("#jobStatusLog").html (text.replace (globalNewline, "<br/>"));
	});

    // Display

    jobOutput.dialog ('open');
    var leftEdge = 600;
    jobOutput.dialog ('option', 'width', $("#tabs").width () - leftEdge + 1);
    jobOutput.dialog ('option', 'height', $("#tabs").height () - 60);
    jobOutput.dialog ('option', 'position', [leftEdge, 41]);



    /*
    var $tabs = $('#tabs').tabs();
    var selected = $tabs.tabs('option', 'selected'); 
    var text = [ '<span id="jobOutPanel">',
		 html.join (''),
		 '</span>' ].join ('');
    $("#tabs-" + (selected + 1) + " > .drawdiv").append (text);
    $("#tabs-" + (selected + 1) + " > .drawdiv").resize (function () {
	    $("#jobOutPanel").css ({
		    height : $(this).height (),
			width  : $(this).width ()
			});
	});
    $("#outputTabs").tabs ();
    */
};

Grayson.prototype.createNode = function (workflow, id, json, fill, geom, shape, annotations, label) {
    if (geom) {
	var nodeGeom = new Geometry (geom.attr ('height'), geom.attr ('width'), geom.attr ('x'), geom.attr ('y'));
	grayson.log_debug ("grayson:node:geom: (h:" + nodeGeom.height + " w:" + nodeGeom.width + " x:" + nodeGeom.x + " y:" + nodeGeom.y + ")");
	if (label) {
	    var labelGeom = new Geometry (label.attr ('height'), label.attr ('width'), label.attr ('x'), label.attr ('y'));
	    grayson.log_debug ("grayson:label:geom: (h:" + labelGeom.height + " w:" + labelGeom.width + " x:" + labelGeom.x + " y:" + labelGeom.y + ")");
	    var node = {
		id        : id,
		graphNode : null,
		instances : [],
		selectedInstance : null,
		annot     : annotations,
		geom      : nodeGeom,
		fill      : fill,
		shape     : shape ? shape.attr ('type') : 'rectangle',
		label     : {
		    geom  : labelGeom,
		    style : {
			"stroke"      : '#000',
			"font-size"   : parseInt (label.attr ('fontSize')) - 2,
			"font-weight" : 'normal',
			"text-anchor" : "start",
			"opacity"     : 1
		    },
		    text  : label.text ()
		}
	    };
	    this.mapNode (workflow, node);
	}
    }
};

Grayson.prototype.initializeFlows = function () {
    this.api.getJSON ("connect_flows", function (flows) {
	    var flowDialog = $("#flowDialog");
	    var flowElement = $("#flows");
	    flowElement.html ("");
	    var text = [];
	    for (var c = 0; c < flows.length; c++) {
		var flow = flows [c];

		var configurationName = basename (flow.flow);
		if (configurationName.indexOf (".") > -1) {
		    configurationName = configurationName.split (".")[0];
		}
		var workflowName = flow.id.replace (".", "_");
		var id = workflowName + "_" + configurationName;
		id = id.replace (/-/g, "_");
		text.push ('<div class="flow" ',
			   '     flow="', flow.flow, '" ',
			   '     flowName="', workflowName, '" ',
			   '       id="', id, '"> ',
			   '             ', flow.id, ' (<b>', configurationName, '</b>)') ;

		for (var g = 0; g < flow.graphs.length; g++)
		    text.push ('  <div class="' + id + '_graph" value="' + flow.flow + "/" + basename (flow.graphs [g]) + '"></div>');
		for (var s = 0; s < flow.daxen.length; s++)
		    text.push ('  <div class="' + id + '_dax" value="' + flow.daxen [s] + '"></div>');
		text.push ('      <div id="' + id + '_runs" class="connectRuns">');
		for (var r = 0; r < flow.runs.length; r++)
		    text.push ('     <div class="' + id + '_run connectFlowRun" ',
			       '          flow="' + flow.flow + '" ',
			       '          runid="' + basename (flow.runs [r]) + '" ',
			       '       flowname="', workflowName, '">',
			       '         ' + flow.runs [r],
			       '         <span class="ui-icon ui-icon-closethick" style="float:right;" title="Delete this run.">close</span> ',
			       '     </div>');
		text.push ('     </div>',
			   '</div>');
	    }
	    flowElement.append ($(text.join ("")));

	    $(".flow").click (function (e) {
		    var id = "#" + $(this).attr ("id") + '_runs';
		    $(id).toggle ();
		});
	    /*
		function (e) {
		    var id = "#" + $(this).attr ("id") + '_runs';
		    $(id).hide ();
		});
	    */
	    $(".connectFlowRun > .ui-icon-closethick").click (function (event) {
		    var flowRun = $(this).parent ();
		    var workdir = flowRun.attr ('flow');
		    var runId = flowRun.attr ('runid');
		    var workflowid = workdir + '/' + flowRun.parent().parent().attr ("flowname").replace ("_dax", ".dax");
		    grayson.api.getJSON ('delete_run/?workdir=' + workdir + '&workflowid=' + workflowid + '&runid=' + runId,
			       function (response) {
				   if (response && response.status == "ok") {
				       flowRun.remove ();
				   } else {
				       grayson.log_error ("error status: " + response);
				   }
			       },
			       function () {
				   alert ('an error occurred deleting workflow (' + workflowid + ') run (' + runId);
			       });

		    event.stopPropagation ();
		});

	    $(".connectFlowRun").click (function (e) {
		    flowDialog.dialog ('close');
		    var workdir = $(this).attr ('flow');
		    var runId = $(this).attr ('runid');
		    var workflowid = workdir + '/' + $(this).attr ("flowname").replace ("_dax", ".dax");
		    var graph = workdir + "/" + basename (workflowid).replace (".dax", ".graphml");
		    grayson.prepareCanvas ();
		    var subworkflowSelector = "." + $(this).parent().parent().attr ('id') + "_dax";
		    $(subworkflowSelector).each (function (index, value) {
			    var subworkflow = $(value).attr ("value");
			    if (subworkflow.indexOf ("-context.graphml") == -1) {
				var flow = $(this).parent().attr ("flow");
				var dax = $(this).parent ().attr ("id");
				var workflowid = flow + "/" + dax.replace ("_dax", ".dax"); 
				grayson.handleEvent ({
					"workflowId" : subworkflow,
					    "event"  : {
					    "type" : "subworkflow.structure",
						"element" : grayson.getBaseId (basename (subworkflow))
						},
					    "clientId" : grayson.getClientId ()
						});
			    }
			});
		    
		    grayson.api.setFlowContext ({
			    workdir        : workdir,
				workflowId : workflowid,
				runId      : runId 
				});
		    grayson.onRenderWorkflow (workflowid, graph);
		    grayson.selectWorkflow (basename (graph).replace (".graphml", ""));
		    //grayson.api.progressPlus (); // TODO: only when we expect an end event, i.e. not local wfs
		    grayson.api.getJSON ('get_flow_events/?workdir=' + workdir + '&workflowid=' + workflowid + '&runid=' + runId,
				      function (response) {
					  if (response && response.status == "ok") {
					  } else {
					      grayson.log_error ("error status: " + response);
					  }
				      });
		});

	    flowDialog.dialog ('option', 'position', [ 20, 35 ]);
	    flowDialog.dialog ('open');
	});
};

Grayson.prototype.setClientId = function (id) {
    this.clientId = id;
};

Grayson.prototype.getClientId = function () {
    return this.clientId;
};

Grayson.prototype.onRenderWorkflow = function (workflow, graphName) {
    var drawdivId = this.tabs.addTab (basename (graphName));
    grayson.log_debug ('grayson:renderworkflow:start');
    $('#' + drawdivId).html ("");
    var paper = Raphael (drawdivId, "100%", "100%"); //1000, 1000);
    //paper.draggable.enable ();
    paper ["connections"] = [];
    var NS = "y\\:";
    if ($.browser.webkit)
	NS = "";
    
    var jsonKey = 'd5'; // ouch
    this.api.getXML ("get_workflow?workflow=" + graphName, function (xml) {

	    grayson.log_debug ('grayson:renderworkflow: getworkflow.success (' + graphName + ')');
	    var nodeDataKey = $(xml).find ("key[attr.name='description'][for='node']").attr ('id');
	    var edgeDataKey = $(xml).find ("key[attr.name='description'][for='edge']").attr ('id');
	    $(xml).find ('key').each (function () {
		var attrName = $(this).attr ('attr.name');
		var isFor = $(this).attr ('for');
		if (attrName == 'description') {
		    var id = $(this).attr ('id');
		    if (isFor == 'node') {
			nodeDataKey = id;
		    } else if (isFor == 'edge') {
			edgeDataKey = id;
		    }
		}
	    });
	    $(xml).find ('node').each (function (){
		var id = $(this).attr ('id');
		var folderType = $(this).attr('yfiles.foldertype');
		if (! folderType) {
		    var json = $(this).find (jsonKey).text ();
		    var fill = $(this).find (NS + 'Fill').attr ('color');
		    var geom = $(this).find (NS + 'Geometry');
		    var shape = $(this).find (NS + 'Shape');
		    var nodeDataExpr = "data[key='" + nodeDataKey + "']";
		    var nodeDataExpr = "data";
		    var annotations = null;
		    $(this).find (nodeDataExpr).each (function () {
			var text = $(this).text ();
			var key = $(this).attr ('key');
			if ( $(this).attr ('key') == nodeDataKey)
			    annotations = $.parseJSON (text);
		    });
		    var label = $(this).find (NS + 'NodeLabel');
		    grayson.createNode (workflow, id, json, fill, geom, shape, annotations, label);
		}
	    });
	    var paths = [];
	    $(xml).find ('edge').each (function () {
		var id = $(this).attr ('id');
		var source = grayson.byId (workflow, $(this).attr ('source'));
		var target = grayson.byId (workflow, $(this).attr ('target'));
		var json = $(this).find (jsonKey).text ();
		$(this).find (NS + 'Path').each (function () {
		    var path = {
			source : source,
			target : target,
			sx : toFloat ($(this).attr ('sx')),
			sy : toFloat ($(this).attr ('sy')),
			tx : toFloat ($(this).attr ('tx')),
			ty : toFloat ($(this).attr ('ty')),
			points : []
		    };
		    paths.push (path);
		    $(this).find (NS + 'Point').each (function () {
			var px = toFloat ($(this).attr ('x'))
			var py = toFloat ($(this).attr ('y'));
			path.points.push ({ x : px, y : py });
			grayson.log_debug ('grayson:parse:point: (x:' + px + ', y:' + py + ')');
		    });
		});
	    });
	    graph = grayson.getGraph (workflow);
	    grayson.renderGraphNodes (workflow, paper);
	    grayson.createConnections (graph, paths, paper);

	    /** process subworkflows */
	    grayson.createFlowSelectors (workflow);
	    grayson.processSubworkflows (workflow); 

	    
	});
};
Grayson.prototype.login = function () {
    var post = {
	username            : $("#login_username").val (),
	password            : $("#login_password").val ()
    };
    grayson.api.postJSON ('login/', post,
			  function (response) {
			      grayson.log_info ("login response " + response);
			      if (response.status === 'ok') {
				  $('#loginDialog').dialog ('close');
				  $('#login_menu').html ("Logout");
			      }
			  });
};

$(document).ready(function() {
	
	grayson = new Grayson ({
		clientId : graysonConf.clientId,
		handlers : [ 
	{ key      : "workflow.structure",
	  callback : function (event) {
		grayson.tabs.initialize ();
		grayson.onRenderWorkflow (event.workflowId, event.event.graph);
		grayson.selectWorkflow (event.event.graph);
	    }
	}, 
	{ key      : "subworkflow.structure",
	  callback : function (event) {
		grayson.subworkflowEvents.push (event);
	    }
	},
	{ key      : "jobstatus",
	  callback : function (event) {
		grayson.onUpdateJobStatus (event);
	    }
	} 
			     ]
	    });

    $('#workflowUploadForm').ajaxForm ({
	    beforeSubmit: function (a, f, o) {
		o.dataType = "json";
		var url = $("#workflowUploadForm").attr ("action");
		o.url = grayson.api.localizeURI (url);
		grayson.prepareCanvas ();
	    },
	    success: function (object) {
		if (object.status && object.status === 'login_required') {
		    $("#loginDialog").dialog ('open');
		} else {
		    var text = JSON.stringify (object);
		    if (object.status == "ok") {
			grayson.log_debug ('ok status');
		    }
		}
		$("#workflowUpload").dialog ('close');		
	    }
    });

    /*
    // BUG: opens in home directory on some platforms instead of last directory.
    // http://www.uploadify.com/forums/discussion/4761/browse-for-files-initial-directory-not-remembering-last-dir/p1
    $('#file_upload').uploadify({
	    'uploader'         : graysonConf.staticDataURL + 'js/uploadify/uploadify.swf',
		'scriptData'   : { 'csrfmiddlewaretoken' : getCookie ('csrftoken') },
		'script'       : grayson.api.localizeURI ('api_run/'),
                'fileDataName' : 'workflow',
		'cancelImg'    : graysonConf.staticDataURL + 'js/uploadify/cancel.png',
		'auto'         : true,
		'onSelect'     : function(event,ID,fileObj) {
		$("#upload_file_name").html (fileObj.name);
	    },
	    'onOpen'       : function(event,ID,fileObj) {
		grayson.prepareCanvas ();
		grayson.api.progressPlus ();
		$('#uploader_message').text('The upload is beginning for ' + fileObj.name);
	    },
	    'onComplete'   : function(event, ID, fileObj, response, data) {
	    },
	    'onAllComplete': function(event, ID, fileObj, response, data) {
		grayson.api.progressMinus ();
		$("#workflowUpload").dialog ('close');
	    },
	    'onError'      : function (event,ID,fileObj,errorObj) {
		alert(errorObj.type + ' Error: ' + errorObj.info);
	    }
	});
    */

    $("#workflowUpload").dialog ({
	    autoOpen : false,
		width : 500,
		height : 300,
		draggable : false,
		resizable : false,
		modal : true
		});

    $("#flowDialog").dialog ({ // connect to existing 
	    autoOpen : false,
		width : 500,
		height : 350,
		draggable : false,
		resizable : false,
		modal : true
		});

    $("#loginDialog").dialog ({
	    autoOpen      : false,
		width     : 500,
		height    : 200,
		draggable : false,
		resizable : false,
		modal     : true
		});
    $("#login_menu").click (function (e) {
	    if ( $("#login_menu").html () == "Login") {
		$("#loginDialog").dialog ('open');
	    } else {
		grayson.api.getJSON ("logout/", function (response) {
			grayson.log_debug ("logged out");
			$("#login_menu").html ("Login");
		    });
	    }
	});
    $("#login_button").click (grayson.login);

    $("#title").click (function (e) {
	    if ( $("#about").is (":visible") ) {
		$("#about").hide ('fade');
		$("#tabs").show ('fade');
	    } else {
		grayson.detailView.hide ();
		$("#tabs").hide ('fade');
		$("#about").show ('fade');		
	    }
	});

    $("#run_menu").click (function (e) {
	    //$("#workflowUpload").dialog ('option', 'position', [ 149, 35 ]);
 	    $("#workflowUpload").dialog ('option', 'position', [ 20, 35 ]); 
	    $("#workflowUpload").dialog ('open'); 
	});

    $("#connect_menu").click (function (e) {
	    grayson.initializeFlows ();
	});

    $("#detail_menu").click (function (e) {
	    grayson.detailView.toggle ();
	});

    $('#jobOutputDialog').dialog({ autoOpen: false, width: 600 });

    $("ul.nav li").hover (function (event) { //When trigger is clicked...  
	    
	    //Following events are applied to the subnav itself (moving subnav up and down)  
	    $(this).parent().find ("ul.subnav").slideDown ().show ('fade'); //Drop down the subnav on click  
	    
	    $(this).parent().hover (function() {  
		},
		function(){  
		    $(this).parent().find("ul.subnav").slideUp('slow'); //When the mouse hovers out of the subnav, move it back up  
		});  
	    
	    //Following events are applied to the trigger (Hover events for the trigger)
        }).hover (function() {  
		$(this).addClass ("subhover"); //On hover over, add class "subhover"  
	    },
	    function(){  //On Hover Out  
		$(this).removeClass ("subhover"); //On hover out, remove class "subhover"  
	    });  

    $(window).resize (function (e) {
	    grayson.fit ();
	});

    /*
    $(document).ajaxSend(function(event, xhr, settings) {
	    if (!safeMethod(settings.type) && sameOrigin(settings.url)) {
		xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
	    }
	});
    */



    });
Grayson.prototype.fit = function () {
    var height = $(window).height () - $("#header").height ();
    $("#workflowTabs").css ({
	    height : height + "px",
	});
};


/*
===============================
==           U T I L         ==
===============================
*/
function isNumber (n) {
    return (typeof (n) == "number");
};

function Geometry (height, width, x, y) {
    this.height = toFloat (height);
    this.width = toFloat (width);
    this.x = toFloat (x);
    this.y = toFloat (y);
};

function toFloat (x) {
    var result = x;
    if (! isNumber (x))
	result = parseFloat (x);
    return (result);
};

function dirname(path) {
    return path.replace(/\\/g,'/').replace(/\/[^\/]*$/, '');;
};

function basename(path) {
    return path.replace(/\\/g,'/').replace( /.*\//, '' );
};

function printObj (obj) {
    for (x in obj) {
	obj.log_debug (">>>:  " + x + " => " + obj[x]);
    }
};


function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
	var cookies = document.cookie.split(';');
	for (var i = 0; i < cookies.length; i++) {
	    var cookie = jQuery.trim(cookies[i]);
	    // Does this cookie string begin with the name we want?
	    if (cookie.substring(0, name.length + 1) == (name + '=')) {
		cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
		break;
	    }
	}
    }
    return cookieValue;
}
function sameOrigin(url) {
    // url could be relative or scheme relative or absolute
    var host = document.location.host; // host + port
    var protocol = document.location.protocol;
    var sr_origin = '//' + host;
    var origin = protocol + sr_origin;
    // Allow absolute or scheme relative URLs to same origin
    return (url == origin || url.slice(0, origin.length + 1) == origin + '/') ||
	(url == sr_origin || url.slice(0, sr_origin.length + 1) == sr_origin + '/') ||
	// or any other URL that isn't scheme relative or absolute i.e relative.
	!(/^(\/\/|http:|https:).*/.test(url));
}
function safeMethod(method) {
    return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
}
