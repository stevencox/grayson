import glob
import grp
import logging
import json
import os
import re
import shutil
import string
import traceback

from django.conf import settings
from django.contrib.auth import authenticate, login
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.template import RequestContext, loader
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.csrf import csrf_exempt    
from django.utils.translation import ugettext as _
from django.contrib.auth import logout
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.decorators import login_required

from web.graysonapp.tasks import ExecuteWorkflow
from web.graysonapp.tasks import MonitorWorkflow
from web.graysonapp.tasks import WorkflowMonitor
from web.graysonapp.LDAPAuthBackend import RENCILDAPBackend
from grayson.util import GraysonUtil
from web.graysonapp.util import GraysonWebConst
from web.graysonapp.util import GraysonWebUtil
from grayson.debug.grid import GridWorkflow

logger = logging.getLogger (__name__)

app_context = {
    GraysonWebConst.TITLE : GraysonWebConst.GRAYSON,
    'URL_PREFIX'          : settings.URL_PREFIX,
    'socketioListenPort'  : settings.SOCKET_IO_PORT 
    }

class GraysonPage:
    home = "app/home.html"
    homePath = "/home/"


@csrf_exempt
def get_response (template, request=None, context={}):
    context [GraysonWebConst.APP] = app_context
    return HttpResponse (loader.
                         get_template ( template ).
                         render (RequestContext (request,
                                                 context)))


def get_json_response (response):
    text = ""
    if response:
        text = json.dumps (response, sort_keys=False, indent=2)
    return HttpResponse (text, GraysonWebConst.MIME_JSON, 200, GraysonWebConst.MIME_JSON)

@csrf_protect
def do_login (request):
    response = {
        "status"  : "fail",
        "message" : _("Failed to authenticate user")
        }
    username = request.POST [GraysonWebConst.USERNAME]
    password = request.POST [GraysonWebConst.PASSWORD]
    logging.info (_("processing authentication request for user[%s]"), username)
    try:
        ldap = RENCILDAPBackend ()
        #user = ldap.authenticate (username = username, password = password)
        user = authenticate (username=username, password=password)
        if user and user.is_active:
            login (request, user)
            request.session [GraysonWebConst.USER] = user
            response ["status"]   = "ok"
            response ["message"]  = _("authenticated")
            response ["clientId"] = user.username 
            app_context [GraysonWebConst.USERNAME] = username
    except Exception as e:
        pass
    return get_json_response (response)

def do_logout (request):
    response = { "status" : "fail" }
    logout (request)
    response ["status"] = "ok"
    return get_json_response (response)

def do_login_required (request):
    return get_json_response ({ "status" : "login_required" })

@csrf_protect
def home (request):
    username = ""
    user = get_user (request)
    if user:
        username = user.username
    context = { "clientId" : username }
    return get_response (GraysonPage.home, request, context)

@login_required
def api_run (request):
    response = { "status" : "ok" }
    try:
        workflowId = None
        logger.debug ("request: %s", request.REQUEST)
        logger.debug ("files: %s", request.FILES)
        if GraysonWebConst.WORKFLOW in request.FILES:
            workflow = request.FILES [GraysonWebConst.WORKFLOW]
            logger.debug (_("Processing uploaded workfow archive: %s."), workflow)
            logger.debug ("Processing uploaded workfow archive: %s.", workflow)
            user = get_user (request)
            file_name = GraysonWebUtil.form_workflow_path (user, workflow.name)
            contentFile = ContentFile (workflow.read ())
            logger.debug ("saving filename: %s", file_name)
            archivePath = default_storage.save (file_name, contentFile)
            logger.debug ("executing workflow...")
            '''
        #group = grp.getgrnam ("apache")
        #logger.debug ("setting group id %s for %s", group.gr_gid, file_name)
        #os.chown (file_name, -1, group.gr_gid)
        #os.chown (os.path.dirname (file_name), -1, group.gr_gid)
            os.chmod (os.path.dirname (file_name), 0777)
        #os.chown (os.path.dirname (os.path.dirname (file_name)), -1, group.gr_gid)
            os.chmod (os.path.dirname (os.path.dirname (file_name)), 0777)            
            '''
            ExecuteWorkflow.delay (user, file_name, archivePath, amqpPort=settings.BROKER_PORT)
            logger.debug ("execute called...")
    except Exception as e:
        logger.error ("Exception occurred during api_run()")
        traceback.print_exc ()  
    logger.debug ("getting response object %s", response)
    return get_json_response (response)

class DebugUser (object):
    username = "scox"

def get_user (request):
    if settings.DEBUG:
        user = DebugUser ()
    else:
        try:
            user = request.session ['user']
        except:
            pass
    return user

@login_required
def get_workflow (request):
    workflow = request.REQUEST ['workflow']
    text = GraysonUtil.readFileAsString (workflow)
    return HttpResponse (text, GraysonWebConst.MIME_XML, 200, GraysonWebConst.MIME_XML)

@login_required
def get_job_output (request):
    user = get_user (request)
    workdir = request.REQUEST ['workdir']
    workflow_id = request.REQUEST ['workflowid']
    job_id = request.REQUEST ['jobid']
    run_id = request.REQUEST ['runid']
    if not run_id:
        run_id = ""
    if not workflow_id:
        workflow_id = ""
    logger.debug ("getting job output: workdir=%s, workflowid: %s, runid: %s, jobid: %s", workdir, workflow_id, run_id, job_id)


    workdirPath = GraysonUtil.form_workdir_path (workdir, user.username, workflow_id, run_id)
    logger.debug ("workdirPath: %s", workdirPath)
    workflow = GridWorkflow (workdirPath)
    outputs = workflow.getOutputFiles (subworkflows = [ ],
                                       item = job_id) 

    jobOutput = None
    if outputs and len (outputs) > 0:
        jobOutput = outputs [0]

    logger.debug ("got job output: %s \n for job_id: %s", jobOutput, job_id)
    text = ""
    if jobOutput:
        text = GraysonUtil.readFileAsString (jobOutput)
    return HttpResponse (text, GraysonWebConst.MIME_TEXT, 200, GraysonWebConst.MIME_TEXT)

@login_required
def connect_flows (request):
    logger.debug ("___________user: %s", request.user)
    user = get_user (request)
    workflowPath = GraysonWebUtil.form_workflow_path (user)
    files = GraysonUtil.getDirs (of_dir=workflowPath)
    workdirs = GraysonUtil.findFilesByName (".*?\.grayson_upk$", files)
    response = []
    for workdir in workdirs:
        conf = GraysonUtil.readJSONFile (os.path.join (workdir, "grayson.conf"))        
        outputFile = conf ["output-file"]
        files = GraysonUtil.getFiles (workdir, recursive=False)
        runs = GraysonUtil.getDirs (os.path.join (workdir, "work", user.username, "pegasus", outputFile.replace (".dax", "")))
        response.append ({
                "flow"   : workdir,
                "id"     : outputFile,
                "runs"   : map (os.path.basename, GraysonUtil.findFilesByName ("[0-9]{8}T[0-9]{6}\-[0-9]{4}$", runs)),
                "graphs" : GraysonUtil.findFilesByName (".*?.graphml$", files),
                "daxen"  : GraysonUtil.findFilesByName ("[a-zA-Z0-9\._\-]+\.dax$", files)
                })
    return get_json_response (response)

@login_required
def get_flow_events (request):
    user = get_user (request)
    workdir = request.REQUEST ["workdir"]
    workflowId = request.REQUEST ["workflowid"]
    runId = request.REQUEST ["runid"]
    
    workflowName = os.path.basename (workflowId).replace (".dax", "")
    workdirPath = GraysonUtil.form_workdir_path (workdir, user.username, workflowName, runId)
    monitor = WorkflowMonitor ()
    monitor.delay (user.username, workflowId, workdirPath, settings.BROKER_PORT)


    return get_json_response ({ "status" : "ok" })

@login_required
def delete_run (request):
    user = get_user (request)
    workdir = request.REQUEST ["workdir"]
    workflowId = request.REQUEST ["workflowid"]
    runId = request.REQUEST ["runid"]
    
    workflowName = os.path.basename (workflowId).replace (".dax", "")
    workdirPath = GraysonUtil.form_workdir_path (workdir, user.username, workflowName, runId)
    logger.debug ("DELETING workflow run: %s", workdirPath)

    shutil.rmtree (workdirPath)
    return get_json_response ({ "status" : "ok" })
    
@login_required
def put_file (request):
    user = get_user (request)
    path = request.REQUEST ["path"]
    content = request.REQUEST ["content"]
    logger.debug ("writing file: %s", path)
    GraysonUtil.writeFile (path, content)
    return get_json_response ({ "status" : "ok" })
    
@login_required
def get_network_profile (request):
    user = get_user (request)
    path = request.REQUEST ["workdir"]
    result = []

    statusPattern = re.compile ("INFO:  Stats:")
    sizePattern = re.compile ("INFO:  Stats: ([0-9]+) ")
    timePattern = re.compile ("transferred in ([0-9]+) seconds.")
    downstreamRatePattern = re.compile ("Rate: ([0-9]+) ??/s")
    upstreamRatePattern = re.compile ("\(([0-9]+) ??/s\)")

    files = GraysonUtil.getFiles (path)
    transfers = GraysonUtil.findFilesByName (".*?/stage_in_.*?.in|.*?/stage_out_.*?.in", files)
    for transfer in transfers:
        text = GraysonUtil.readFileAsString (transfer)
        lines = text.split ("\n")
        current = 0
        while current < len (lines) - 5:
            kickstart = transfer.replace (".in", ".out.000")
            if os.path.exists (kickstart):
                stream = None
                try:
                    try:
                        stream = open (kickstart, "r")
                        for line in stream:
                            '''
                            statcallIndex = line.rfind ("<statcall")
                            if statcallIndex > -1:
                                line = line.rstrip ()
                                parts = line.split (' ')
                                if len (parts) >= 3:
                                    c = 0
                                    for p in parts:                                        
                                        if p == "<statcall":
                                            logger.debug (">>>>>>>>>>>>>>>> %s", line)
                                            parts = parts [c + 1].split ('"')
                                            record ['exitcode'] = parts [1]
                                            break
                                        c += 1
                                        '''
                            if line.rfind ("INFO:  Stats:") > -1:
                                logger.debug ("--: %s", line)

                                parts = line.split (' ')

                                if len(parts) >= 18:
                                    if parts [8] == 'no':
                                        pass
                                    else:
                                        record = {}
                                        record ['destinationSite'] = lines [current]
                                        record ['destinationPath'] = lines [current + 1]
                                        record ['sourceSite']      = lines [current + 2]
                                        record ['sourcePath']      = lines [current + 3]                                        
                                        record ['size'] = parts [8]
                                        record ['time'] = parts [12]
                                        record ['down'] = "%s %s" % (parts [15], parts [16])
                                        record ['up']   = "%s %s" % (parts [17], parts [18])
                                        result.append (record)
                    finally:
                        if stream:
                            stream.close ()
                except IOError, e:
                    traceback.print_exc ()
            current += 4
    return get_json_response (result)
