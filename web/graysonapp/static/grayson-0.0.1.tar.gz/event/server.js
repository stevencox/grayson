var express = require ('express')
    , sys  = require ('sys')
    , amqp = require ('amqp')
    , url  = require ('url')
    , fs   = require ('fs')
    , io   = require ('socket.io')
    , sys  = require (process.binding('natives').util ? 'util' : 'sys')
    , server;

data = fs.readFileSync ('conf/grayson.conf', 'utf-8');
configuration = JSON.parse (data);
buffer = [];

/** =============================================================== 
             S O C K E T . I O
    =============================================================== */
var server = express.createServer ()
    , io = io.listen(server)
    , sockets = { }
    , messageID = 0;

io.set('log level', 1); 

server.listen (configuration.socketioListenPort);

sys.puts ("Connected; listening on port: " + configuration.socketioListenPort);

var connection = amqp.createConnection (configuration.amqpSettings);
connection.addListener ('ready', function () {
	sys.puts ("Connected to " + connection.serverProperties.product);
	var exchange = connection.exchange ("");
	var queue = connection.queue ('workflow', configuration.queueSettings);
	queue.bind (exchange, '#');
	queue.subscribe ("workflow", function (message) {
	        log_info (message.data);
		try {
		    log_info (message.data);
		    var event = JSON.parse (message.data);
		    var clientConnection = sockets [event.clientId];
		    if (! clientConnection) {
			clientConnection = new GraysonConnection (event.socketId);
			sockets [event.socketId] = clientConnection;
		    }
		    clientConnection.send (event);
		} catch (e) {
		    log_error ("exception: " + e.message + "\nmessage: ");
		    printObj (message);
		}
	    });
	io.sockets.on ('connection', function (socket) {
		log_info ('connection: ' + socket.sessionId);
		socket.on ('subscribe', function (message) {
			log_info ("--message: " + message);
			var object = JSON.parse (message);
			if (object) {
			    var clientId = object.clientId;
			    printObj (object);
			    if (object.subscribe === "on") {
				log_info ("client " + clientId + " registering for messages");
				var clientConnection = sockets [clientId];
				if (! clientConnection) {
				    log_info ("--(new-socket): " + clientId);
				    clientConnection = new GraysonConnection (clientId, socket);
				    sockets [clientId] = clientConnection;
				} else {
				    log_info ("--(reconnect): " + clientId);
				    clientConnection.setSocket (socket);
				}
			    }
			}
		    });
		socket.on ('disconnect', function () {
			sys.puts (socket.sessionId + " disconnected...");
		    });
	    });
    });
connection.addListener('error', function(connectionException){
	if (connectionException.errno === process.ECONNREFUSED) {
	    sys.log('ECONNREFUSED: connection refused to '
		    +connection.host
		    +':'
		    +connection.port);
	} else {
	    sys.log(connectionException);
	}
    });

/** =============================================================== 
    Socket
    =============================================================== */
function GraysonConnection (socketId, socket) {
    this.socketId = socketId;
    this.socket = socket;
    this.buffer = [];
};
GraysonConnection.prototype.setSocket = function (socket) {
    this.socket = socket;
    this.flush ();
};
GraysonConnection.prototype.send = function (event) {
    var message = JSON.stringify (event);
    if (this.socket) {
	log_info ("--(emit):-[id:" + messageID++ + ", cli:" + this.socketId + ", msg: " + message + "]");
	//this.flush ();
	this.socket.emit ('message', message);
    } else {
	this.buffer.push (event)
    }
};
GraysonConnection.prototype.flush = function () {
    var event = null;
    for (var c = 0; c < this.buffer.length; c++) {
	event = this.buffer [c];
	if (event) {
	    if (event.socketId === this.socketId) {
		log_info ("--(buffer-send): " + event);
		this.socket.emit ('message', event);
		this.buffer.remove (c);
	    }
	}
    }
};

/** =============================================================== 
             Util
    =============================================================== */
function printObj (obj) {
    for (x in obj)
	sys.puts ("  '" + x + "':'" + obj [x] + "'");
}
function log_info (m) {
    sys.puts (new Date() + "INFO: " + m);
}
function log_error (m) {
    sys.puts (new Date() + "ERROR: " + m);
}
function contains(a, obj){
  for(var i = 0; i < a.length; i++) {
    if(a[i] === obj){
      return true;
    }
  }
  return false;
}
// Array Remove - By John Resig (MIT Licensed)
Array.prototype.remove = function(from, to) {
    var rest = this.slice((to || from) + 1 || this.length);
    this.length = from < 0 ? this.length + from : from;
    return this.push.apply(this, rest);
};
