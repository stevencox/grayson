{
    "listenPort" : 8080,
    "amqpSettings" : {
          "host"     : "localhost"
	, "port"     : 5672
	, "login"    : "guest"
	, "password" : "guest"
	, "vhost"    : "/"
     },
     "queueSettings" : {
        "durable"     : false,
	"autoDelete"  : false,
	"exclusive"   : false
     }
}

