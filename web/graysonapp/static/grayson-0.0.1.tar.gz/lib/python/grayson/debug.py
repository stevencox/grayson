#!/usr/bin/env python

import logging
import getopt
import glob
import os
import re
import sys
import string
import traceback

from grayson.util import GraysonUtil

''' ./20110811T094112-0400/wind.0.dax_ID0000001/slice.2.dax_ID0000003/padcswan-beta.20_ID0000007/padcswan_1n2.out.000 '''

logger = logging.getLogger (__name__)

class GridWorkflow (object):
    def __init__(self, workdir, jobs):
        self.workdir = workdir
        self.jobs = jobs
        
    def getAllFiles (self):
        outputfiles = []
        print "grayson:gridworkflow: getting workdir files: %s" % self.workdir
        for root, dirs, files in os.walk (self.workdir):
            for f in files:
                fullpath = os.path.join (root, f)
                outputfiles.append (fullpath)
        return outputfiles

    def getJobOutput (self, subworkflows=[], jobid=None):
        result = None
        output = []
        files = self.getAllFiles ()
        path = []
        for sub in subworkflows:
            sub = sub.replace (".dax", "")
            path.append ("%s_.*?" % sub)
        pattern = "".join (path)
        if jobid:
            text = ".*?%s/%s.*?.out.000" % (pattern, jobid)
            print "--: text: %s" % text
            pattern = re.compile (text)
            output = self.findFile (pattern, files)
        else:
            for job in self.jobs:
                text = ".*?%s/%s.*?.out.0??" % (pattern, job)
                print "--: text: %s" % text
                pattern = re.compile (text)
                output = self.findFile (pattern, files)
        if len(output) == 1:
            result = output [0]
        else:
            for out in output:
                print "===================== %s" % out

        return result

    def findFile (self, pattern, files):
        output = []
        for file in files:
            if pattern.search (file):
                print "_______: %s" % file
                output.append (file)

        return output

class GridWorkflowMonitor (object):
    def __init__(self, workdir, jobs):
        self.workflow = GridWorkflow (workdir, jobs)

    def execute (self):
        files = self.workflow.getJobOutput ()
        for out in files:
            event = {
                "workflow" : out,
                
                }
            print "%s" % out

'''    
monitor = GridWorkflowMonitor ("samples/padcswan/work/scox/pegasus/padcswan-uber/20110811T094112-0400",
                               [ "padcswan_1n2", "package_1n4", "merge_1n6" ])
monitor.execute ()
'''
