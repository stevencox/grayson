
import json
import logging
import time

from grayson.net.amqp import GraysonAMQPTransmitter
from grayson.util import GraysonUtil

logger = logging.getLogger (__name__)

class EventStream (object):

    def __init__(self, port):
        self.port = port
        self.count = 0

    def publish (self, event):        
        logger.debug ("publishing: %s on port %s", event, self.port)
        amqp = GraysonAMQPTransmitter (GraysonUtil.WORKFLOW_QUEUE, port=self.port)
        text = json.dumps (event, indent=4)
        amqp.send ([ text ])
        self.count += 1
        logger.debug ("message count: %s",  self.count)

    def sendJobStatusEvent (self, username, workflowId, jobid, status, logdir="", evt_time=None):
        if not evt_time:
            evt_time = time.time ()
        logger.debug ("event-stream:send:job-status: user(%s) wfid(%s) jobid(%s) status(%s) logdir(%s) time(%s)",
                       username, workflowId, jobid, status, logdir, evt_time)
        self.publish ({
                "clientId"   : username, 
                "workflowId" : workflowId,
                "event"      : {
                    "type"   : "jobstatus",
                    "job"    : jobid,
                    "time"   : evt_time,
                    "state"  : status,
                    "logdir" : logdir
                    }
                })
    def sendWorkflowEvent (self, username, workflowId, graphPath):
        logger.debug ("event-stream:send:workflow-evt: user(%s) wfid(%s) graph(%s)", username, workflowId, graphPath)
        self.publish ({ 
                "clientId"   : username, 
                "workflowId" : workflowId,
                "event"      : {
                    "type"   : "workflow.structure",
                    "graph"  : graphPath
                    }
                })
    def sendSubworkflowEvent (self, username, workflowId, graphPath):
        logger.debug ("event-stream:send:subworkflow-evt: user(%s) wfid(%s) graph(%s)", username, workflowId, graphPath)
        self.publish ({ 
                "clientId"   : username, 
                "workflowId" : workflowId,
                "event"      : {
                    "type"    : "subworkflow.structure",
                    "element" : graphPath
                    }
                })
    
    def sendEndEvent (self, username, workflowId):
        logger.debug ("event-stream:send:end-evt: user(%s) wfid(%s)", username, workflowId)
        self.publish ({
                "clientId"   : username,
                "workflowId" : workflowId,
                "event"      : {
                    "time"   : time.time (),
                    "type"    : "endEventStream",
                    }
                })
