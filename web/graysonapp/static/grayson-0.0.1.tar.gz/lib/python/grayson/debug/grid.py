#!/usr/bin/env python

import logging
import getopt
import glob
import os
import re
import sys
import string
import traceback
import time

from grayson.util import GraysonUtil
from grayson.debug.event import EventStream

logger = logging.getLogger (__name__)
            
class GridWorkflow (object):

    def __init__(self, workdir):
        self.workdir = workdir

    def getJobOutput (self, subworkflows=[], jobid=None):
        result = None
        list = self.getOutputFiles (subworkflows, "%s.*?.out.000" % jobid)
        if list:
            result = list [0]
        return result

    def getOutputFiles (self, subworkflows=[], item=None):
        output = []
        path = []

        files = GraysonUtil.getFiles (self.workdir)

        for sub in subworkflows:
            sub = sub.replace (".dax", "")
            path.append ("%s_.*?" % sub)
        pattern = "".join (path)

        if type (item) == unicode or type (item) == str:
            output = GraysonUtil.findFilesByName (".*?%s/%s" % (pattern, item), files)
        elif type(item) == list:
            for output in item:
                partial = GraysonUtil.findFilesByName (".*?%s/%s" % (pattern, output), files)
                for element in partial:
                    output.append (element)
        return output

class GridWorkflowMonitor (object):

    SUBMIT = "SUBMIT"
    EXECUTE = "EXECUTE"
    JOB_SUCCESS = "JOB_SUCCESS"
    JOB_FAILURE = "JOB_FAILURE"
    DAGMAN_FINISHED = "DAGMAN_FINISHED"
    ALL_CODES = [ SUBMIT, EXECUTE, JOB_SUCCESS, JOB_FAILURE, DAGMAN_FINISHED ]

    STATUS_PENDING = "pending"
    STATUS_EXECUTING = "executing"
    STATUS_SUCCEEDED = "succeeded"
    STATUS_FAILED = "failed"

    def __init__(self, workflowId, username, workdir, amqpPort=None):
        logger.debug ("gridworkflowmonitor:init")
        self.workflow = GridWorkflow (workdir)
        self.tracker = {}
        self.workflowId = workflowId
        self.username = username
        self.monitorRunning = False
        self.eventStream = EventStream (amqpPort)

    def execute (self, loop=True):
        self.monitorRunning = True
        while self.monitorRunning:
            logs = self.workflow.getOutputFiles ([], "jobstate.log")
            rootLog = os.path.join (self.workflow.workdir, "jobstate.log")
            if logs:
                for out in logs:
                    track = 0
                    if out in self.tracker:
                        track = self.tracker [out]
                    try:
                        states = open (out, "r")
                        try:
                            count = 0
                            for line in states:
                                if count > track:
                                    logdir = os.path.dirname (out)
                                    self.detectEvent (logdir, line)
                                count += 1
                                self.tracker [out] = count
                        except IOError, e:
                            traceback.print_stack ()
                    finally:
                        states.close ()
            if loop:
                time.sleep (3)
            else:
                self.monitorRunning = False
                logger.debug ("debug:grid:endevent: user(%s) workflow(%s)", self.username, self.workflowId)
        self.eventStream.sendEndEvent (self.username, self.workflowId)

    def finish (self):
        self.monitorRunning = False
        logger.debug ("debug:grid:endevent: user(%s) workflow(%s)", self.username, self.workflowId)
        self.eventStream.sendEndEvent (self.username, self.workflowId)

    def sendEvent (self, logdir, evt_time, jobId, status):
        self.eventStream.sendJobStatusEvent (username   = self.username,
                                             workflowId = self.workflowId,
                                             jobid      = jobId,
                                             status     = status,
                                             logdir     = logdir,
                                             evt_time   = evt_time)

    def detectEvent (self, logdir, line):
        if GraysonUtil.containsAny (line, GridWorkflowMonitor.ALL_CODES):
            parts = line.split (" ")
            logger.debug ("          (detect) %s", line)
            
            time  = parts [0]
            jobId = parts [1]
            code  = parts [2]
            
            if code == GridWorkflowMonitor.SUBMIT:
                self.sendEvent (logdir, time, jobId, GridWorkflowMonitor.STATUS_PENDING)
            elif code == GridWorkflowMonitor.EXECUTE:
                self.sendEvent (logdir, time, jobId, GridWorkflowMonitor.STATUS_EXECUTING)
            elif code == GridWorkflowMonitor.JOB_SUCCESS:
                self.sendEvent (logdir, time, jobId, GridWorkflowMonitor.STATUS_SUCCEEDED)
            elif code == GridWorkflowMonitor.JOB_FAILURE:
                self.sendEvent (logdir, time, jobId, GridWorkflowMonitor.STATUS_FAILED)
            elif parts [3] == GridWorkflowMonitor.DAGMAN_FINISHED:
                status = parts [4]
                self.monitorRunning = False
                exitCode = self.STATUS_FAILED
                if status == "0":
                    exitCode = self.STATUS_SUCCEEDED
                self.sendEvent (logdir, time, jobId, exitCode) 
