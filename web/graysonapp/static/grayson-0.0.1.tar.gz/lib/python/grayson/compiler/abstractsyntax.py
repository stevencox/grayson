# -*- coding: utf-8 -*-

''' system '''
from string import Template
from copy import copy
import getopt
import json
import logging
import logging.handlers
import os
import re
import shlex
import shutil
import string
import socket
import subprocess
import sys
import time
import traceback
import glob
from sys import settrace

''' local '''
from grayson.graphml import Edge
from grayson.graphml import Graph
from grayson.graphml import GraphMLParser
from grayson.graphml import Node
from grayson.log import LogManager
from grayson.util import GraysonUtil

class ASTProfile (object):
    def __init__(self, namespace, key, value):
        self.namespace = namespace
        self.key = key
        self.value = value
    
''' Abstract representation of an element comprising '''
class ASTElement:

    def __init__(self, node):
        self.ATTR_TYPE = "type"
        self.node = node
        self.properties = { "id" : self.node.getId () }
        self.daxNode = None
        properties = self.parseProperties ()
        if properties:
            self.setProperties (properties)
            
    def parseProperties (self):
        properties = None
        id = self.node.getId ()
        text = self.node.getType ()
        if id and text:
            try:
                text = string.replace (text, "\n", " ")
                properties = json.loads (text)
            except:
                message = "ERROR:ast:parse-json: node(id=%s, label=%s, json=%s)" % (id, self.node.getLabel (), text)
                logging.error (message)
                self.setProperties ({ "type" : None })
                traceback.print_exc ()
                raise ValueError (message)
        return properties

    def getProperties (self):
        return self.properties
	
    def setProperties (self, properties):
        logging.debug ("ast:setprop: (%s,%s)=>%s", self.getId(), self.getLabel (), properties)
        if not properties:
            properties = {}
        self.properties = properties
        self.properties ["id"] = self.node.getId ()
            
    def addAncestor (self, ancestor):
        if ancestor:
            self.mergePropertiesFrom (ancestor)
            
    def addProfiles (self, other):
        if other:
            self.mergePropertiesFrom (other, tag="inherit-profiles")

    def mergePropertiesFrom (self, other, exceptions=["id", "type"], tag="inherit"):
        if other:
            self.properties = self.mergePropertiesDeep (self.properties,
                                                        other.getProperties (),
                                                        exceptions)
            logging.debug ("ast:%s: obj(%s)<-anc(%s)=[%s]" % 
                          (tag,
                           self.node.getLabel(),
                           other.getNode().getLabel (),
                           self.properties))
            
    def mergePropertiesDeep (self, left, right, exceptions=[]):
        if left and right:
            for key in right:
                if key in exceptions:
                    continue
                value = right [key]
                if key in left:
                    if type(value) == dict:
                        value = self.mergePropertiesDeep (left[key], value)
                    else:
                        logging.debug ("ast:keep-key: left[%s]->[%s]" % (key, value))
                else:
                    left [key] = right [key]
                    logging.debug ("ast:copy-key: left[%s]->[%s]" % (key, value))
        return left

    def get (self, key):
        value = None
        if key in self.properties:
            value = self.properties [key]
        return value

    def set (self, key, value):
        self.properties [key] = value
	
    def getLabel (self):
        return self.node.getLabel ()

    def getId (self):
        return self.node.getId ()

    def getType (self):
        return self.get(self.ATTR_TYPE)
    
    def getNode (self):
        return self.node

    def getContext (self):
        return self.node.getContext ()

    def setDaxNode (self, daxNode):
        self.daxNode = daxNode

    def getDaxNode (self):
        return self.daxNode
    
    def getProfiles (self):
        profiles = None
        if self.properties:
            profileList = None
            if 'profiles' in self.properties:
                profileList = self.properties ['profiles']
                if profileList:
                    profiles = []
                    for namespace in profileList:
                        space = profileList [namespace]
                        for key in space:
                            if key:
                                value = space [key]
                                if value:
                                    logging.debug ("ast:get-profiles: (%s)-(%s=%s)" % (namespace, key, value))
                                    profile = ASTProfile (namespace, key, value)
                                    profiles.append (profile)
        return profiles

    def getOrigins (self, graph):
        origins = []
        if self.node:
            edges = graph.getEdges ()
            id = self.node.getId ()
            for edge in edges:
                # this edge points at this node #
                if edge.getTarget () == id:
                    origin = graph.getNode (edge.getSource ())
                    # record the originating node #
                    if origin:
                        logging.debug ("ast:add-origin: ((%s)%s) of ((%s)%s)" % (origin.getId(),
                                                                                     origin.getLabel(), 
                                                                                     self.getId(),
                                                                                     self.getLabel()) )
                        origins.append (origin.getId ())
        return origins

    def getOriginEdges (self, graph, edgeType=None):
        originEdges = []
        if self.node:
            edges = graph.getEdges ()
            id = self.node.getId ()
            for edge in edges:
                # this edge points at this node #
                if edge.getTarget () == id:
                    originEdges.append (edge)
        return originEdges

    def getAncestorsByType (self, graph, type, ancestors = []):
        if self.node:
            edges = graph.getEdges ()
            id = self.node.getId ()
            for edge in edges:
                # this edge points at this node #
                if edge.getTarget () == id:
                    ancestor = graph.getNode (edge.getSource ())
                    # record the originating node #
                    if ancestor:
                        logging.debug ("ast:add-ancestor: (%s) of (%s)" % (ancestor.getLabel(), self.getLabel()) )
                        if ancestor.getId () in ancestors:
                            raise ValueError ("invalid use of getAncestorsByType on a graph with cycles.")
                        ancestors.append (ancestor.getId ())
                        self.getAncestorsByType (graph, type, ancestors)
        return ancestors

    def getTargets (self, graph):
        targets = []
        if self.node:
            edges = graph.getEdges ()
            id = self.node.getId ()
            for edge in edges:
                # this edge points at this node #
                if edge.getSource () == id:
                    target = graph.getNode (edge.getTarget())
                    # record the originating node #
                    if target:
                        logging.debug ("ast:add-target: (%s) of (%s)" % (target.getLabel(), self.getLabel()) )
                        targets.append (target.getId ())
        return targets

    def getTargetEdges (self, graph):
        targetEdges = []
        if self.node:
            edges = graph.getEdges ()
            id = self.node.getId ()
            for edge in edges:
                # this edge points at this node #
                if edge.getSource () == id:
                    targetEdges.append (edge)
        return targetEdges
            
if __name__ == '__main__':
    test_grayson_compiler ()



