# -*- coding: utf-8 -*-

''' system '''
import getopt
import glob
import json
import logging
import logging.handlers
import os
import re
import shlex
import shutil
import socket
import string
import subprocess
import sys
import time
import traceback
from copy import copy
from string import Template
from sys import settrace

''' local '''
from grayson.compiler.abstractsyntax import ASTElement
from grayson.compiler.exception import GraysonCompilerException
from grayson.executor import Executor
from grayson.graphml import Edge
from grayson.graphml import Graph
from grayson.graphml import GraphMLParser
from grayson.graphml import Node
from grayson.log import LogManager
from grayson.packager import GraysonPackager
from grayson.util import GraysonUtil
from grayson.wms.pegasus.pegasusWMS import PegasusWMS
from grayson.wms.workflowManagementSystem import WorkflowManagementSystem

''' Compiler Plugin '''
class CompilerPlugin (object):
    def notifyShellEvent (self, line, outputWorkflowPath):
        pass
    def notifyWorkflowCreation (self, workflowGraph, outputWorkflowPath, topWorkflow):
        pass

''' Test Job '''
class ASTTestJob:

    def __init__(self, name, executable=None, compiler=None):
        self.name = name
        self.executable = executable
        self.args = []
        self.children = []
        self.map = {}
        self.compiler = compiler
        self.prerequisiteFiles = []

    def addArguments (self, args):
        if args:
            for arg in args:
                self.args.append (arg)

    def addPrerequisiteFile (self, fileName):
        self.prerequisiteFiles.append (fileName)

    def getName (self):
        return self.name
    
    def getText (self):
        value = None
        if self.executable:
            value = self.executable #value = "python %s" % self.executable
            if not os.sep == "/":
                value = "%s %s" % ("python", value)
            for arg in self.args:
                value = "%s %s" % (value, arg)
        return value

    def addChild (self, child):
        self.children.append (child)

    def getChildren (self):
        return self.children

    def execute (self, executor):
        for fileName in self.prerequisiteFiles:
            filePath = os.path.join (os.getcwd (), "..", fileName)
            if not os.path.exists (filePath):
                raise ValueError ("Missing required file [%s] in test job [%s]" % (filePath, self.name))
        if self.executable == "workflow" and self.compiler:
            logging.info ("execute:workflow: %s", self.name)
            self.compiler.executeTest ()
        else:
            commandLine = self.getText ()
            if commandLine:
                logging.info ("execute-test: job [%s], executable [%s]\n    [%s] ", self.name, self.executable, commandLine.replace (" -", "\n\t-"))
                executor.execute (commandLine)

class ASTContext:
    def __init__(self):
        self.dependencies = {}
        self.wmsjobs = {}
    def addWmsJob (self, id, job):
        self.wmsjobs [id] = job
    def getWmsJobs (self):
        return self.wmsjobs
    def getWmsJob (self, id):
        value = None
        if id in self.wmsjobs:
            value = self.wmsjobs [id]
        return value
    def setDependencies (self, id, dependencies):
        self.dependencies[id] = dependencies
    def getDependencies (self, id):
        value = None
        if id in self.dependencies:
            value = self.dependencies [id]
        return value

class JobContext:
    def __init__(self, job, namespace, version):
        self.job = job
        self.testJob = None
        self.origins = []
        self.inputFiles = []
        self.outputFiles = []
        self.inFiles = {}
        self.outFiles = {}
    def getJob (self):
        return self.job
    def setTestJob (self, testJob):
        self.testJob = testJob
    def getTestJob (self):
        return self.testJob
    def addOrigin (self, origin):
        logging.debug ("job context add origin: origin(%s) job(%s, %s)", origin, self.job.getId (), self.job.getLabel ())
        if origin == self.job.getId ():
            logging.debug ("maybe-bad: %s shows itself as the source of one of its own input files. Hopefully this is an aspect.", self.job.getLabel ()) 
        else:
            if not origin in self.origins:
                self.origins.append (origin)
    def getOrigins (self):
        return self.origins
    
class CompilerContext (object):
    def __init__(self):
        self.topModel = None
        self.properties = ASTElement (Node ("x", "{}", ""))
        self.localFileLocations = {}
        self.aspects = []
        self.sites = "local"
        self.workflowManagementSystem = PegasusWMS ()
        self.processedWorkflows = []
        self.inputModelProperties = {}
        self.allModelPaths = []
        self.packaging = False
        self.compilerPlugin = CompilerPlugin ()
    def getWorkflowManagementSystem (self):
        return self.workflowManagementSystem
    
''' Read a graph structure and convert to semantics suitable for a particular workflow management system. '''
class GraysonCompiler:

    SYNTHETIC_ID = 0
    LAMBDA_ID = 0

    def __init__(self, namespace, version, logManager, test=False, clean=False, appHome=None):
        self.ABSTRACT = "abstract"
        self.APP_HOME = unicode ("appHome")
        self.OUTPUT_DIR = unicode ("outputDir")
        self.FQDN = "FQDN"
        self.ASPECT  = "aspect"
        self.ATTR_ARCHITECTURE  = "arch"
        self.ATTR_ARG  = "arg"
        self.ATTR_ARGS  = "args"
        self.ATTR_INSTALLED = "installed"
        self.ATTR_LOCAL = "local"
        self.ATTR_PATH = "path"
        self.ATTR_REFERENCE  = "reference"
        self.ATTR_SITE = "site"
        self.ATTR_TYPE = "type"
        self.ATTR_VERSION  = "version"
        self.EXECUTABLE = "executable"
        self.FILE = "file"
        self.GRAYSON_FILE_ARG = "grayson.file.arg"
        self.GRAYSONPATH = "GRAYSONPATH"
        self.GRAYSON_REDIRECT_OUTPUT_TO = "grayson.redirect.output.to"
        self.INPUT = "in"
        self.JOB = "job"
        self.OUTPUT = "out"
        self.PROPERTIES = "properties"
        self.WORKFLOW = "workflow"
        self.DAX = "dax"
        self.MAP = "map"
        self.TEST_MAP = "testMap"

        self.CONTEXT_MODEL = "context"
        self.MODEL_SUFFIX = "graphml"
        self.CONTEXT_MODEL_TAG = "-context.graphml"
        
        self.EXECUTION_MODE = "execution-mode"
        self.EXECUTION_MODE__SHELL = "shell"
        self.CONF_INPUT_PROPERTIES = "define"
        self.CONF_OUTPUT_FILE = "output-file"
        self.CONF_SITES = "sites"
        self.CONF_FILE = "grayson.conf"

        self.ASPECT_POINTCUT = "pointcut"
        self.ASPECT_FROM = "from"
        self.ASPECT_TO = "to"
        self.VARIABLE = "variable"
        self.PATTERN = "pattern"

        self.SYMLINK_TRANSFER = "symlink"
        self.URL_PREFIX = "urlPrefix"
        
        self.compilerId = ""
        self.namespace=namespace
        self.version=version
        self.logManager = logManager

        self.output = None
        self.graph = None
        self.workflowCompiler = {}
        self.astElements = {}
        self.typeIndex = {}
        self.labelIndex = {}
        self.validModel = True
        self.errorMessages = []
        self.syntheticIds = {}

        self.test = test         # Run tests
        self.clean = clean       # Delete previous artifacts and tests
        self.appHome = appHome   # Home directory of the application
        self.testJobs = {}       # Execute test jobs
        self.roots = []          # Jobs that dont depend on other jobs
        self.contextModels = []  # Models that provide context (are not workflows)

        self.compilerContext = CompilerContext ()
        self.workflowModel = self.compilerContext.getWorkflowManagementSystem().createWorkflowModel (self.namespace)
         
        path = os.getenv (self.GRAYSONPATH)
        logging.debug ("compiler:init:modelpath: pathvar: %s: path: %s separator: %s", self.GRAYSONPATH, path, os.pathsep)
        if path:
            self.compilerContext.modelPath = path.rsplit (os.pathsep)
        else:
            self.compilerContext.modelPath = [ ".", "model" ]

        for element in self.compilerContext.modelPath:
            logging.debug ("compiler:init:pathelement: %s", element)

    def setCompilerPlugin (self, compilerPlugin):
        self.compilerContext.compilerPlugin = compilerPlugin
    def getCompilerPlugin (self):
        return self.compilerContext.compilerPlugin

    def setPackaging (self, packaging=False):
        self.compilerContext.packaging = packaging

    def isPackaging (self):
        return self.compilerContext.packaging

    def setTopModel (self, topModel):
        self.compilerContext.topModel = topModel

    def getTopModel (self):
        return self.compilerContext.topModel
    
    def isTopModel (self):
        return self.compilerContext.topModel == self.compilerId
    
    def isContextModel (self):
        isContext = self.CONTEXT_MODEL_TAG in self.compilerId 
        logging.debug ("is-context-model: %s -> %s", self.compilerId, isContext)
        return isContext
    
    def setSites (self, sites):
        self.compilerContext.sites = sites

    def getSites (self):
        return self.compilerContext.sites

    def getTransformationCatalog (self):
        return self.compilerContext.getWorkflowManagementSystem().getTransformationCatalog ()

    def getReplicaCatalog (self):
        return self.compilerContext.getWorkflowManagementSystem().getReplicaCatalog ()
    
    def getSiteCatalog (self):
        return self.compilerContext.getWorkflowManagementSystem().getSiteCatalog ()

    def writeMetaDataCatalogs (self):
        self.compilerContext.getWorkflowManagementSystem().writeMetaDataCatalogs ()

    def getWorkflowManagementSystem (self):
        return self.compilerContext.getWorkflowManagementSystem()
    
    def setInputModelProperties (self, properties):
        self.compilerContext.inputModelProperties = properties

    def getInputModelProperties (self):
        return self.compilerContext.inputModelProperties

    def setModelPath (self, path):
        self.compilerContext.modelPath = path

    def getModelPath (self):
        return self.compilerContext.modelPath

    def setOutputDir (self, outputDir):
        self.compilerContext.getWorkflowManagementSystem().setOutputDir (outputDir)
        self.workflowModel.setWorkflowRoot (outputDir)

    def getOutputDir (self):
        return self.compilerContext.getWorkflowManagementSystem().getOutputDir ()
    
    def getProperty (self, key):
        return self.compilerContext.properties.get (key)

    def parse (self, models=[], graph=None):

        ''' order models '''
        final_models = []
        if models:
            for model in models:
                if model.endswith (self.CONTEXT_MODEL_TAG):
                    self.contextModels.append (model)
                else:
                    final_models.append (model)
            for model in models:
                if model.endswith (self.CONTEXT_MODEL_TAG):
                    final_models.append (model)

        if len (final_models) > 0:
            parser = GraphMLParser ()
            self.compilerId = final_models [0]
            self.graph = parser.parseMultiple (final_models,
                                               path=self.compilerContext.modelPath,
                                               graph=graph)
        else:
            message = "Empty model list. Supply at least one model file."
            logging.error (message)
            raise ValueError (message)

        for path in self.graph.fileNames:
            if not path in self.compilerContext.allModelPaths:
                logging.debug ("add-model-path: %s", path)
                self.compilerContext.allModelPaths.append (path)

    def getAllModelPaths (self):
        return self.compilerContext.allModelPaths

    def addElement (self, id, element):
        if not isinstance (element, ASTElement):
            raise ValueError ("Accepts ASTElement only. Got: %s", element)
        elementType = element.get (self.ATTR_TYPE)
        self.astElements [id] = element
        if elementType:
            if not elementType in self.typeIndex:
                self.typeIndex[elementType] = []
            self.typeIndex [elementType].append (element)
            node = element.getNode ()
            if isinstance (node, Node) and not elementType == self.ATTR_REFERENCE:
                self.labelIndex [node.getLabel ()] = element
            else:
                logging.debug ("ast:add-element:rejecting reference element: %s", node.getLabel ())

    def removeElement (self, id):
        if id in self.astElements:
            element = self.astElements [id]
            if element:
                elementType = element.getType ()
                if elementType in self.typeIndex:
                    del self.typeIndex [elementType]
                label = element.getLabel ()
                if label in self.labelIndex:
                    del self.labelIndex [label]
            del self.astElements [id]
        self.graph.removeNode (id)
        edges = self.graph.getEdges ()
        for edge in edges:
            if edge.getTarget () == id or edge.getSource () == id:
                self.graph.removeEdge (edge)
                if edge.getId () in self.astElements:
                    del self.astElements [edge.getId ()]
                logging.debug ("      removing edge: %s src:%s target:%s",
                               id,
                               edge.getSource(),
                               edge.getTarget ())

    def getElementByLabel (self, label):
        value = None
        if label in self.labelIndex:
            value = self.labelIndex [label]
        return value

    def getElementsByType (self, type):
        value = []
        if type in self.typeIndex:
            value = self.typeIndex [type]
        return value

    def getElementKeys (self):
        return self.astElements.keyiter ()

    def getElementsById (self, ids, accept=None):
        result = []
        for id in ids:
            element = self.getElement (id)
            if element:
                if accept:
                    if element.getType () == accept:
                        result.append (element)
                else:
                    result.append (element)
        return result

    def getElement (self, id):
        value = None
        if id in self.astElements:
            value = self.astElements [id]
            if value:
                type = value.get (self.ATTR_TYPE)
                if type == self.ATTR_REFERENCE:
                    referencedValue = None
                    node = value.getNode ()
                    if node:
                        label = node.getLabel ()
                        if label:
                            referencedValue = self.getElementByLabel (label)
                            if referencedValue:
                                logging.debug ("ast:dereference: (%s) to object (%s)" % 
                                               (label,
                                                referencedValue.getNode().getLabel ()))
                                value = referencedValue
                            else:
                                self.addError ("(cid=%s): unable to find concrete object referenced by label: %s" % (self.compilerId, value.getNode().getLabel ()))
                                logging.error ("(cid=%s): unable to find concrete object referenced by label: %s" % (self.compilerId, value.getNode().getLabel ()))
                                traceback.print_stack ()
                                self.graph.dump ()
                                for key in self.labelIndex:
                                    logging.debug ("        == %s ( %s )", key, self.labelIndex [key])
                                value = None
        return value

    def addError (self, message):
        logging.error (message)
        self.errorMessages.append (message)

    def reportErrors (self):
        for message in self.errorMessages:
            logging.error ("%s" % message)

    def failValidation (self, message):
        self.addError (message)
        self.validModel = False
        
    def validateGraph (self):
        nodes = self.graph.getNodes ()
        edges = self.graph.getEdges ()
        if not nodes:
            self.addError ("the graph is empty (contains no nodes)")
        elif not edges:
            self.addError ("the graph is empty (contains no edges)")
        else:
            return 
            #Check for cycles.            
            # L <= Empty list where we put the sorted elements
            # Q <= Set of all nodes with no incoming edges
            # while Q is non-empty do
            #     remove a node n from Q
            #     insert n into L
            #     for each node m with an edge e from n to m do
            #         remove edge e from the graph
            #         if m has no other incoming edges then
            #             insert m into Q
            # if graph has edges then
            #     output error message (graph has a cycle)
            # else 
            #     output message (proposed topologically sorted order: L)
            #
            sortedElements = []      # L
            targetedNodes = []       # Q            
            for edge in edges:
                targeted = edge.getTarget ()
                if not targeted in targetedNodes:
                    targetedNodes.append (targeted)
            while len (targetedNodes) > 0:
                id = targetedNodes [0]
                targetedNodes.remove (id)
                sortedElements.append (id)
                for edge in edges:
                    edgeTarget = edge.getTarget ()
                    if edge.getSource () == id:
                        edges.remove (edge)
                        otherIncomingEdge = False
                        for otherEdge in edges:
                            if otherEdge.getTarget () == edgeTarget:
                                otherIncomingEdge = True
                                break
                        if not otherIncomingEdge:
                            targetedNodes.append (edgeTarget)
            if len(edges) > 0:
                for edge in edges:
                    source = self.getElement (edge.getSource ())
                    target = self.getElement (edge.getTarget ())
                    logging.error ("   cycle edge: %s to %s", source.getLabel (), target.getLabel ())
                raise ValueError ("graph has a cycle")
                
    def validateModel (self):
        logging.debug ("validate-graph")
        for key in self.astElements.iterkeys ():
            element = self.getElement (key)
            if element:
                if element.get (self.ATTR_TYPE) == self.FILE:
                    fileName = element.getNode().getLabel ()
                    if not os.path.exists (fileName):
                        self.failValidation ("File: %s does not exist." % fileName)

    def addExecutable (self, jobContext, source):
        job = jobContext.getJob ()
        jobLabel = job.getNode().getLabel ()
        site = source.get (self.ATTR_SITE)
        path = source.get (self.ATTR_PATH)
        path = os.path.normpath (path)
        installed = source.get (self.ATTR_INSTALLED)
        architecture = source.get (self.ATTR_ARCHITECTURE)
        logging.debug ("ast:add-executable: job=%s", jobLabel)



        urlPrefix = source.get (self.URL_PREFIX)
        if urlPrefix:
            path = "%s/%s" % (urlPrefix, source.getLabel ())



        exe = self.workflowModel.addExecutable (jobId = job.getId (),
                                                name = jobLabel,
                                                path = path,
                                                version = self.version,
                                                site = site,
                                                exe_arch = architecture,
                                                installed = installed)
        self.getTransformationCatalog().addEntry (jobName=jobLabel,
                                                  location=path,
                                                  transfer=installed,
                                                  cluster=site,
                                                  namespace=self.namespace)
        source.setDaxNode (exe)
        job.addProfiles (source)
        jobContext.setTestJob (ASTTestJob (jobLabel, path))

    def getFileURL (self, fileElement, site=None):
        if not site:
            site = self.ATTR_LOCAL
            
        fileName = fileElement.getLabel ()
        fileURL = self.getSiteCatalog().getScratchURL (fileName, site)
        urlPrefix = fileElement.get (self.URL_PREFIX)
        if urlPrefix:
            fileURL = "%s/%s" % (urlPrefix, fileName)

        symlinkTransfer = fileElement.get (self.SYMLINK_TRANSFER)
        if symlinkTransfer == str(True).lower ():
            self.getWorkflowManagementSystem().enableSymlinkTransfers ()
            
        logging.debug ("fileURL: %s, urlPrefix %s", fileURL, urlPrefix)
        return fileURL
    
    def addOutputFile (self, jobContext, fileElement, edge):
        job = jobContext.getJob ()
        fileName = fileElement.getNode().getLabel ()
        file = self.workflowModel.createFile (fileName)
        fileElement.setDaxNode (file)
        arg = edge.get (self.ATTR_ARG)
        logging.debug ("ast:add-output: arg=%s file=%s source=%s" % 
                      (arg,
                       fileName,
                       job.getNode().getLabel ()) )
        jobContext.outFiles [fileElement.getLabel ()] = (fileElement, arg)        
        self.getReplicaCatalog().addEntry (fileName,
                                           self.getFileURL (fileElement),
                                           self.ATTR_LOCAL)
        
    def addInputFile (self, jobContext, fileElement, edge):
        job = jobContext.getJob ()
        fileName = fileElement.getLabel ()
        inputOrigins = fileElement.getOrigins (self.graph)
        for o in inputOrigins:
            logging.debug ("ast:origin: %s" % o)
            jobContext.addOrigin (o)
        arg = edge.get (self.ATTR_ARG)
        site = fileElement.get (self.ATTR_SITE)
        if not site:
            site = self.ATTR_LOCAL
        logging.debug ("ast:add-input: arg=%s file=%s job=%s site=%s", 
                      arg,
                      fileName,
                      job.getNode().getLabel (),
                      site)
        fileURL = self.getFileURL (fileElement, site),
        logging.debug ("get-file-url: %s", fileURL)
        if site == self.ATTR_LOCAL:
            if fileName in self.compilerContext.localFileLocations:
                fileURL = self.compilerContext.localFileLocations [fileName]
        file = self.workflowModel.addFile (fileName, fileURL, site)
        fileElement.setDaxNode (file)
        jobContext.inFiles [fileElement.getLabel ()] = (fileElement, arg)
        self.getReplicaCatalog().addEntry (fileName,
                                           self.getFileURL (fileElement, site),
                                           site)

    def formWorkflowName (self, element):
        return "%s.dax" % element.getLabel ()

    def getLogicalName (self, text):
        result = text
        match = re.search ('(.*)\.([0-9]+)', result)
        if match:
            result = match.group (1)
        return result
    
    def formWorkflowSourceName (self, element):
        result = self.getLogicalName (element.getLabel ())
        logging.debug ("ast:form-workflow-name: %s from element %s", result, element.getLabel ())
        return "%s.%s" % (result, self.MODEL_SUFFIX)

    ''' Create a compiler object, promoting this compiler context. '''
    def createComponentCompiler (self, elementName, version):
        logging.debug ("ast:compile-component: start(%s)" % elementName )
        compiler = GraysonCompiler (namespace = elementName,
                                    version = version,
                                    logManager = self.logManager,
                                    test = self.test,
                                    clean = self.clean,
                                    appHome = self.appHome)
        compiler.compilerContext = self.compilerContext
        return compiler

    ''' Execute the compiler semantic analysis and output. '''
    def executeCompiler (self, compiler, elementName, outputFile):
        compiler.buildAST ()
        if not self.isPackaging ():
            outputFileName = os.path.join (self.getOutputDir (), outputFile)
            output = open (os.path.join (self.getOutputDir (), outputFile), "w")
            compiler.writeDAX (output)
            output.close ()

            isTopWorkflow = self.output and outputFileName.endswith (self.output)
            '''
            self.getCompilerPlugin().notifyWorkflowCreation (elementName,     #self.getLogicalName (elementName),
                                                             outputFileName,
                                                             isTopWorkflow)
                                                             '''
            self.getCompilerPlugin().notifyWorkflowCreation (self.getLogicalName (elementName),
                                                             outputFileName,
                                                             isTopWorkflow)

        outputDir = self.getOutputDir ()
        fileURL = "file://%s/%s" % (outputDir, outputFile)
        if outputDir == ".":
            fileURL = "file://%s/%s" % (os.getcwd (), outputFile)
        self.getReplicaCatalog().addEntry (outputFile, fileURL, "local") 
        logging.debug ("ast:compile-component:end: (%s)" % elementName )

    ''' Given an element, find a graph model named like the element but with the appropriate suffix 
        Compile that model into a workflow. '''

    def ast_compileWorkflow (self, element):
        elementName = element.getLabel ()
        compiler = self.createComponentCompiler (elementName, element.get (self.ATTR_VERSION))
        workflowName = self.formWorkflowName (element)
        modelName = self.formWorkflowSourceName (element)
        models = models = [ modelName ]
        ''' add context models '''
        for contextModel in self.contextModels:
            logging.debug ("ast:compile-workflow:add-context-model: %s", contextModel)
            models.append (contextModel)
        ''' load graphs '''
        compiler.parse (models)

        ''' If the element has a context element, perform substitutions. '''
        context = element.getContext ()
        if context:
            logging.debug ("ast:compile-workflow:context: %s for %s", context, element.getLabel ())
            nodes = compiler.graph.getNodes ()
            for node in nodes:
                text = node.getType ()
                if text:
                    node.setType (self.replaceMapVariables (text, context))
                    logging.debug ("ast:compile-workflow:context:text: (%s)-> %s", node.getLabel (), node.getType ())
                node.setLabel (self.replaceMapVariables (node.getLabel (), context))

        ''' Compile and write output '''
        self.executeCompiler (compiler, elementName, workflowName)
        self.workflowCompiler [element.getId ()] = compiler

    ''' Compile a synthetic workflow from a generated graph to an output file. '''
    def ast_compileSyntheticWorkflow (self, element, workflowName, graph, syntheticNode):
        compiler = self.createComponentCompiler (workflowName, element.get (self.ATTR_VERSION))

        if len (graph.nodes) == 0:
            text = "each map operator"
            if element:
                text = "map operator: (%s)\n(%s)" % (element.getLabel (), element.getNode().getType ())
            if not self.isPackaging ():
                raise ValueError ("An empty synthetic graph was passed: Verify that map operators evaluate to non empty graphs in this environment for %s" % text)

        compiler.parse (self.contextModels, graph)

        compiler.compilerId = workflowName
        self.executeCompiler (compiler, element.getLabel (), workflowName)
        self.workflowCompiler [element.getId ()] = compiler
        self.workflowCompiler [syntheticNode.getId ()] = compiler

    ''' Determine job precedence and recognize root jobs. '''
    def ast_createDependencies (self, daxContext):
        logging.debug ("ast:dependencies:")
        self.roots = []
        wmsjobs = daxContext.getWmsJobs ()
        for jobId in wmsjobs:
            job = daxContext.getWmsJob (jobId)
            logging.debug ("ast:dependency:job-id: %s" % jobId)
            dependencySet = daxContext.getDependencies (jobId)
            if dependencySet:
                for key in dependencySet:
                    dependency = None
                    logging.debug ("ast:dependency:key: (%s)" % key)
                    dependency = daxContext.getWmsJob (key)
                    if dependency:
                        logging.debug ("ast:dependency:add: (%s)=>(%s)" % (jobId, key))
                        self.workflowModel.addDependency (parent=dependency, child=job)
                        parentTestJob = self.testJobs [key]
                        childTestJob = self.testJobs [jobId]
                        if childTestJob and parentTestJob:
                            parentTestJob.addChild (childTestJob)
            else:
                logging.debug ("ast:dependency: add root job (%s)", jobId)
                self.roots.append (jobId)

    ''' Build aggregate properties based on property nodes in all read graphs '''
    def ast_properties (self):        
        logging.debug ("ast:prop:init")
        properties = self.compilerContext.properties.getProperties ()
        if not self.MAP in properties:
            properties [self.MAP] = {}
        properties [self.MAP][self.APP_HOME] = self.appHome.replace ("\\", "/")
        properties [self.MAP][self.OUTPUT_DIR] = self.getOutputDir ()
        properties [self.MAP][self.FQDN] = socket.getfqdn ()

        ''' Aggregate each properties object encountered by the parser. '''
        propertyNodes = self.graph.getPropertyList ()
        for propertyNode in propertyNodes:
            element = ASTElement (propertyNode)
            self.compilerContext.properties.mergePropertiesFrom (element)
            logging.debug ("ast:prop:update: %s", self.compilerContext.properties.getProperties ())

        ''' If in test mode, incorporate test properties. '''
        basics = self.getProperty (self.MAP)
        if self.test:
            testProperties = self.getProperty (self.TEST_MAP)
            if testProperties and basics:
                basics.update (testProperties)
                logging.debug ("ast:prop:updated properties to test mode\n   %s" % basics)

        ''' If command line properties were given, override using those. '''
        for key in self.getInputModelProperties ():
            value = self.getInputModelProperties() [key]

            valueTemplate = Template (value)
            value = valueTemplate.safe_substitute (basics)

            logging.debug ("ast:prop:adding model property %s = %s", key, value)
            properties [self.MAP][key] = value

        ''' If execution mode is shell, configure the workflow management system appropriately '''
        if self.EXECUTION_MODE in basics and basics[self.EXECUTION_MODE] == self.EXECUTION_MODE__SHELL:
            logging.debug ("setting shell execution mode for workflow: %s", self.compilerId)
            self.getWorkflowManagementSystem().enableShellExecution ()

        logging.debug (properties)

    ''' Replace map variables in the text '''
    def replaceMapVariables (self, text, context):
        value = text

        variableMask = "${"
        mapVariableMask = "@{"
        
        mapExpressionPattern = re.compile ("@{(.*?)}", re.I|re.U)
        for match in mapExpressionPattern.finditer (text):
            overall = match.group (0)
            expression = match.group (1)
            logging.debug ("ast:replace-map-vars:match: %s %s", overall, expression)
            isAnExpression = re.search ("[+\-\*\\/\%(\)\<\>\==]", expression)
            if isAnExpression:
                for key in context:
                    logging.debug ("ast:replace-map-vars:replace: %s %s in expr: %s", key, unicode (context[key]), expression)
                    expression = expression.replace (key, unicode (context[key]))
                text = text.replace (overall, unicode (eval (expression)))
            logging.debug ("ast:replace-map-vars:  outcome%s", text)

        if text and variableMask in text or mapVariableMask in text:
            for contextKey in context:
                for pattern in [ "%s%s", "%s{%s}" ]:
                    orig_pattern = pattern % ("@", contextKey)
                    new_pattern = pattern % ("$", contextKey)
                    text = text.replace (orig_pattern, new_pattern)
            template = Template (text)
            value = template.safe_substitute (context)
        return value

    ''' Create a synthetic id given a base id and prefix '''
    def getSyntheticId (self, baseId, prefix):
        result = baseId
        id = -1
        if prefix in self.syntheticIds:
            self.syntheticIds[prefix] += 1
        else:
            self.syntheticIds[prefix] = 0
        id = self.syntheticIds[prefix]
        if id == -1:
            self.SYNTHETIC_ID += 1
            id = self.SYNTHETIC_ID
        result = "%s.%s" % (result, id)
        return result

    def nextLambdaId (self):
        value = self.LAMBDA_ID
        self.LAMBDA_ID = self.LAMBDA_ID + 1
        return value

    class MapOperatorContext (object):
        def __init__(self, graph, operator, element, context={}, originEdges=[], is_chained=False):
            self.graph = graph
            self.operator = operator
            self.element = element
            self.context = {}
            self.originEdges = originEdges
            self.is_chained = is_chained
        def setLastInstance (self, lastInstance):
            self.lastInstance = lastInstance
        def getLastInstance (self):
            return self.lastInstance
        def getElement (self):
            return self.element
        def getOperator (self):
            return self.operator
        def getContext (self):
            return self.context
        def getOrigins (self):
            return self.originEdges
        def getChained (self):
            return self.is_chained

    '''
        Execute map operator on an operand.
            i.   If operand is itself a map operator, execute the operand as a map operator
            ii.  If operand is a workflow, copy it
                    a. Registering a context object for later pattern replacement
                    b. Copying edges to and from copied object
                    c. Chaining between elements if chaining is on    
    '''
    def ast_synthesizeInstance (self, graph, is_chained, last_instance, operator, operand, context, origins=[]):
        node = None
        type = operand.getType ()
        if type == self.MAP:
            ''' Recursively process a map operand which is itself a map operator '''
            targets = operand.getTargets (self.graph)
            for targetId in targets:
                target = self.getElement (targetId)
                if target:
                    node = self.ast_executeMapOperator (parent_graph = graph,
                                                        operator = operand,
                                                        element = target,
                                                        input_context = context,
                                                        originEdges = origins)
        else:
            ''' Create a new graph node replacing mapping parameters '''
            typeText = self.replaceMapVariables (operand.getNode().getType (), context)
            nodeId = self.getSyntheticId (operand.getId (), operand.getLabel ())
            nodeName = "%s.%s" % (operand.getLabel (), self.nextLambdaId ())
            node = graph.addNode (nodeId, nodeName, typeText)
            node.setContext (copy (context))
            ''' Map inputs to this synthetic instance copying input nodes to the synthetic graph '''
            for edge in origins:
                source = self.getElement (edge.getSource ())
                source = self.findOrCopy (source, graph)
                self.copyEdge (graph, edge, source, node)
            ''' if chaining is on, chain each instance to its predecessor node '''
            logging.debug ("is_chained (%s), last_instance(%s)", is_chained, last_instance)
            if is_chained and last_instance:
                parentId = last_instance.getId ()
                childId = node.getId ()
                graph.addEdge ("%s%s" % (parentId, childId), parentId, childId)
                logging.debug ("chained instance %s as parent of %s", parentId, childId)
        return node

    ''' Edit the graph to bind the synthetic node where the operand and operator were:
              i)   Create a new DAX node
              ii)  Point to it from the operators origin nodes
              iii) Point from it to the operands target nodes
    '''
    def ast_bindSyntheticNode (self, graph, operand, nodeId, nodeLabel, nodeType, origins):
        node = graph.addNode (nodeId, nodeLabel, nodeType)
        for edge in origins:
            source = self.getElement (edge.getSource ())
            source = self.findOrCopy (source, graph)
            self.copyEdge (graph, edge, source, node)
        targets = operand.getTargetEdges (graph)
        for edge in targets:
            if not type(edge) == unicode: 
                target = self.getElement (edge.getTarget ())
                target = self.findOrCopy (target, graph)
                self.copyEdge (graph, edge, node, target)
        return node

    '''
    Create a sub-graph to turn into a workflow
         Allow a sub-graph of only one node (a workflow or job)
         The operand the map operator points to will be duplicated, nothing else.
         An operand which is itself an operator will be executed before emitting a sub-workflow
    '''
    def ast_executeMapOperator (self, parent_graph, operator, element, input_context = {}, originEdges = []):
        FILE_PROTO = "file://"
        MAP_STYLE__CHAIN = "chain"
        MAP__STYLE = "style"
        MAP__VARIABLE = "variable"
        MAP__EACH = "each"
        MAP__START = "start"
        MAP__END = "end"
        operator = self.ast_mapNode (operator.getNode ())
        variable = operator.get (MAP__VARIABLE)
        each = operator.get (MAP__EACH)
        logging.debug ("ast:map:each: %s type: %s %s", each, type (each), variable)
        is_chained = operator.get (MAP__STYLE) == MAP_STYLE__CHAIN
        synthetic_graph = Graph ()
        last_instance = None
        context = {}
        for key in input_context:
            context [key] = input_context [key]
        inboundEdges = operator.getOriginEdges (self.graph)
        logging.debug ("ast:map:origin-edges")
        for edge in inboundEdges:
            edgeElement = self.getElement (edge.getId ())
            if edgeElement:
                source = self.getElement (edgeElement.getNode().getSource ())
                target = self.getElement (edgeElement.getNode().getTarget ())
                if edgeElement.getType () == self.INPUT:
                    logging.debug ("ast:map:origin-edge: inheriting edge (%s) from (%s, %s) to (%s, %s)",
                                   edgeElement.getId (),
                                   source.getId (),
                                   source.getLabel (),
                                   target.getId (),
                                   target.getLabel ())
                    originEdges.append (edge)
        if type(each) == dict:
            if MAP__START in each and MAP__END in each:
                start = int (each [MAP__START])
                end = int (each [MAP__END])
                for c in range (start, end):
                    logging.debug ("ast:map(%s)(loop)[start=%s,end=%s,cur=%s,element=%s]", self.compilerId, start, end, c, element.getLabel ())
                    context [variable] = c
                    last_instance = self.ast_synthesizeInstance (synthetic_graph,
                                                                 is_chained,
                                                                 last_instance,
                                                                 operator,
                                                                 element,
                                                                 context,
                                                                 originEdges)
        elif ( type(each) == str or type(each) == unicode) and string.find (each, FILE_PROTO) > -1:
            index = string.find (each, FILE_PROTO)
            expression = each [ index + len(FILE_PROTO): ]
            files = glob.glob (expression)
            files.sort ()
            for file in files:
                logging.debug ("ast:map(%s)(glob)[item=%s,expression=%s,element=%s]", self.compilerId, file, expression, element.getLabel ())
                file = file.replace (os.path.sep, "/")
                context [variable] = file
                basename = os.path.basename (file)
                context ["%s_base" % variable] = basename

                ''' Publish each file via GridFTP from this host in the replica catalog. '''
                fileAbsolutePath = os.path.abspath (file)
                fileURL = "gsiftp://%s/%s" % (socket.getfqdn (), fileAbsolutePath)
                self.getReplicaCatalog().addEntry (basename, fileURL, self.ATTR_LOCAL)

                ''' Register the file as a local file for later reference. '''
                self.compilerContext.localFileLocations [basename] = "file://%s" % fileAbsolutePath                
                last_instance = self.ast_synthesizeInstance (synthetic_graph,
                                                             is_chained,
                                                             last_instance,
                                                             operator,
                                                             element,
                                                             context,
                                                             originEdges)
        '''
        The map operators operand has been mapped to concrete instances
           (a) Generated synthetic instances are in synthetic_graph.
           (b) The synthetic_graph is about to be emitted as an executable workflow
           (c) Edit parent_graph to bind the synthetic node where the operator/operand were
         '''
        syntheticId = self.getSyntheticId (operator.getId (), operator.getLabel ())
        number = syntheticId.split(".")[1]
        syntheticLabel = "%s.%s" % (operator.getLabel (), number)
        syntheticType = '{ "type" : "dax" }'
        syntheticNode = self.ast_bindSyntheticNode (parent_graph,
                                                    element,
                                                    syntheticId,
                                                    syntheticLabel,
                                                    syntheticType,
                                                    originEdges)
        logging.debug ("add-synth-node: (%s) added to synthgraph of operator (%s)", syntheticNode.getLabel (), operator.getLabel ())
        workflowName = "%s.%s" % (syntheticNode.getLabel (), self.DAX)
        workflowName = self.replaceMapVariables (workflowName, input_context)
        self.ast_compileSyntheticWorkflow (operator, workflowName, synthetic_graph, syntheticNode)

        return syntheticNode

    def copyEdge (self, graph, edge, source, target, edgeType=None):
        edgeId = "%s.%s" % (edge.getId (), target.getId ())
        if not edgeType:
            edgeType = edge.getType ()
        edgeCopy = graph.addEdge (edgeId, source.getId (), target.getId (), edgeType)
        self.ast_mapEdge (edgeCopy)
        logging.debug ("ast:copy-edge: from (%s(%s)->%s(%s))type(%s)",
                       source.getLabel (),
                       source.getId (),
                       target.getLabel (),
                       target.getId (),
                       edgeType)
        return edgeCopy
    
    def findOrCopy (self, element, graph):
        end_element = graph.getNodeByLabel (element.getLabel ())
        if not end_element:
            end_element = graph.addNode ("%s.synth" % element.getId (),
                                         element.getLabel (),
                                         element.getNode().getType ())
        return end_element

    def ast_finalizeMapOperator (self, operator, element):
        logging.debug ("ast:map:finalize %s", element)
        inboundEdges = operator.getOriginEdges (self.graph)
        logging.debug ("ast:map:finalize:inbound-edges %s", inboundEdges)
        for edge in inboundEdges:
            logging.debug ("ast:map:finalize: inbound edge %s", edge)
            self.removeElement (edge)
        self.removeElement (operator.getId ())
        if element.getType () == self.MAP:
            targets = element.getTargets (self.graph)
            for targetId in targets:
                target = self.getElement (targetId)
                if target:
                    self.ast_finalizeMapOperator (element, target)
        else:
            logging.debug ("ast:map:finalize operand: %s", element.getLabel ())
            self.removeElement (element.getId ())

    def ast_getMapTargets (self, operator):
        targetEdges = []
        edges = operator.getTargetEdges (self.graph)
        for edge in edges:
            target = self.getElement (edge.getTarget ())
            if target.getType () == self.MAP:
                operandTargets = self.ast_getMapTargets (target)
                for item in operandTargets:
                    targetEdges.append (item)
            else:
                edges = target.getTargetEdges (self.graph)
                for e in edges:
                    targetEdges.append (e)
        return targetEdges

    def ast_processMapOperators (self):
        operators = self.getElementsByType (self.MAP)
        if operators:
            for operator in operators:
                logging.debug ("map:operator:execute %s", operator.getLabel ())
                sources = operator.getOrigins (self.graph)
                isRoot = True
                for sourceId in sources:
                    source = self.getElement (sourceId)
                    if not source:
                        logging.debug ("map:operator: couldn't find %s" % sourceId)
                    elif source.getType () == self.MAP:
                        isRoot = False
                        break
                if isRoot:
                    ''' execute the operator for each mapped object '''
                    logging.debug ("map:operator:collect: targets: %s", operator.getLabel ())
                    targets = operator.getTargets (self.graph)
                    for targetId in targets:
                        target = self.getElement (targetId)
                        if target:
                            logging.debug ("map:operator:executing: for target: %s", target.getLabel ())
                            targetEdges=[]
                            node = self.ast_executeMapOperator (parent_graph=self.graph,
                                                                operator=operator,
                                                                element=target,
                                                                input_context={},
                                                                originEdges=[])                            
                            ''' add the results of the map operator execution into the graph '''
                            self.graph.addExistingNode (node)
                            self.ast_mapNode (node)
                            targetEdges = self.ast_getMapTargets (operator)
                            for edge in targetEdges:
                                if not type(edge) == unicode and not type(edge) == str:
                                    target = self.getElement (edge.getTarget ())

                                    self.copyEdge (self.graph, edge, node, target)
                            logging.debug ("map:operator: added synthetic dax node: %s (%s)",
                                           node.getLabel (),
                                           node.getType ())
                    for targetId in targets:
                        target = self.getElement (targetId)
                        self.ast_finalizeMapOperator (operator, target)

    def ast_weaveAspects (self):
        '''
        an aspect is a workflow.
        it will be woven in as a subworkflow
        as such, pointcut effectively address transitions (edges) between nodes.
        after mapNodes and mapEdges
            for each edge 
                read the aspect pointcut instructions
                for each matching node in the graph:
                    create a component workflow representing the aspect graph (i.e. traditional subworkflow)
                    insert the node at the right position in the graph
        '''
        logging.debug ("ast:aspect:weave")
        edges = self.graph.getEdges ()
        self.graph.dump ()
        for edge in edges:
            source = self.getElement (edge.getSource ())
            target = self.getElement (edge.getTarget ())
            if not source:
                continue #raise ValueError ("broken graph: couldn't find source node %s" % edge.getSource ())
            if not target:
                continue #raise ValueError ("broken graph: couldn't find target node %s" % edge.getTarget ())
            logging.debug ("ast:aspect:weave:got: (source=%s) (target=%s)", source.getLabel (), target.getLabel ())
            for pointcut in self.compilerContext.aspects:
                if not pointcut.getType () == self.ASPECT_POINTCUT:
                    continue                
                logging.debug ("--weaving: %s", pointcut.getProperties ())
                fromElement = pointcut.get (self.ASPECT_FROM)
                toElement = pointcut.get (self.ASPECT_TO)
                variable = pointcut.get (self.VARIABLE)
                pattern = pointcut.get (self.PATTERN)
                aspectName = pointcut.get (self.ASPECT)                
                if not toElement and not fromElement:
                    raise ValueError ("an aspect must have either 'to' or 'from' node specified")
                if not pattern:
                    raise ValueError ("an aspect must specify a file pattern")
                if not aspectName:
                    raise ValueError ("unable to determine aspect name for pointcut %s " % pointcut.getProperties ())
                jobNode = source
                fileElement = target
                jobPattern = fromElement
                if toElement:
                    fileElement = source
                    jobNode = target
                    jobPattern = toElement
                matchesJob = re.search (jobPattern, jobNode.getLabel ()) 
                matchesFile = re.search (pattern, fileElement.getLabel ())
                if matchesJob and matchesFile:
                    logging.debug ("--weaving: matched pointcut: %s", pointcut.getProperties ())
                    if toElement:
                        pass
                    elif fromElement:
                        '''
                        create workflow node referencing aspect
                        copy the file node
                        copy the edge with the new workflow as source and new file node as target
                        change all of the original file nodes outbound edges sources to be new file node
                        '''
                        logging.debug ("--weaving: generating synthetic aspect node")
                        synthId = self.getSyntheticId (jobNode.getId (), aspectName)
                        number = synthId.split(".")[1]
                        aspectId = "%s.%s" % ( aspectName, synthId)
                        aspectNodeName = "%s.%s" % (aspectName, number)
                        aspectNode = self.graph.addNode (aspectId, aspectNodeName, ' { "type" : "workflow" } ' )
                        aspectNode.setContext ({
                            variable : fileElement.getLabel ()
                            })
                        aspectElement = self.ast_mapNode (aspectNode)

                        logging.debug ("--weaving: generating synthetic file node type(%s)", fileElement.getNode().getType ())
                        synthFileId = "%s.%s" % (fileElement.getId (), self.getSyntheticId (fileElement.getId (), fileElement.getLabel ()))
                        number = synthFileId.split(".")[1]
                        synthFileName = fileElement.getLabel ()
                        synthFileType = '{ "type" : "reference" }'
                        synthFile = self.graph.addNode (synthFileId, synthFileName, synthFileType)
                        synthFileElement = self.ast_mapNode (synthFile)
                        
                        logging.debug ("--weaving: generating synthetic edge")
                        toAspectEdge = self.copyEdge (self.graph, edge, aspectElement, synthFileElement)
                        fromAspectEdge = self.copyEdge (self.graph, edge, fileElement, aspectElement, '{ "type" : "in" }')

                        logging.debug ("--weaving: remapping old file targets to use synth file as target")
                        targetEdges = fileElement.getTargetEdges (self.graph)
                        for targetEdge in targetEdges:
                            fileTarget = targetEdge.getTarget ()
                            ''' never target the synthetic file at the aspect which is now a target of the original file. '''
                            if not fileTarget == aspectElement.getId ():
                                target = self.getElement (targetEdge.getTarget ())
                                logging.debug ("   synth file element now points to %s ", target.getLabel ())
                                targetEdge.setSource (synthFileElement.getId ())

    def ast_mapNode (self, node, raiseErrors=True):
        nominal = True
        jsonText = node.getType ()
        if jsonText and "$" in jsonText:
            template = Template (jsonText)
            context = self.getProperty ("map")
            if not context:
                context = {}
            try:
                logging.debug ("ast:map-node:subs: txt:%s \n                   map:%s",
                               jsonText.replace ("\n", " "),
                               json.dumps (context).replace ("\n", " "))
                jsonText = template.substitute (context)
                node.setType (jsonText)
                logging.debug ("ast:map-node:settype: (%s)" % jsonText)
            except KeyError:
                nominal = False
                self.addError ("property %s is not defined for element: %s" % (sys.exc_value, node.getLabel ()))
                traceback.print_stack ()
                if raiseErrors:
                    raise ValueError ("property %s is not defined for element: %s" % (sys.exc_value, node.getLabel ()))
        element = ASTElement (node)
        logging.debug ("ast:map-node:add-element: label=(%s) type=(%s)", element.getLabel (), node.getType ())
        self.addElement (node.getId (), element)
        return element

    def ast_mapStaticNode (self, node):
        element = None
        jsonText = node.getType ()
        if jsonText and not "$" in jsonText:
            node.setType (jsonText)
            element = ASTElement (node)
            logging.debug ("ast:map-static:mapping[%s]: %s %s %s)", self.compilerId, node.getId(), node.getLabel (), node.getType ())
            self.addElement (node.getId (), element)
        return element

    ''' Map nodes (and property resolution) '''
    def ast_mapNodes (self):
        jobs = []
        logging.debug ("ast:map-nodes: (cid=%s)", self.compilerId)

        ''' read existing nodes and map them '''
        nodes = self.graph.getNodes ()
        for node in nodes:
            self.ast_mapStaticNode (node)
        
        ''' load context models '''
        logging.debug ("is-top-model: %s", self.isTopModel ())
        if self.isTopModel ():
            contextModelElements = self.getElementsByType (self.CONTEXT_MODEL)
            contextModelFiles = []
            for contextModel in contextModelElements:
                fileName = "%s%s" % (contextModel.getLabel (), self.CONTEXT_MODEL_TAG)
                if not fileName in self.getTopModel ():
                    contextModelFiles.append (fileName)
            if len(contextModelFiles) > 0:
                compilerId = self.compilerId
                self.parse (contextModelFiles, self.graph)
                self.compilerId = compilerId
        
        if self.isContextModel ():
            if self.isTopModel ():
                self.ast_buildSubWorkflows (jobs)
        else:
            ''' resolve properties '''
            self.ast_properties ()

            ''' map nodes in the graph '''
            nodes = self.graph.getNodes ()
            for node in nodes:
                self.ast_mapNode (node)

            ''' expand map operators '''
            self.ast_processMapOperators ()
            edgeElements = self.ast_mapEdges ()

            ''' register aspects '''
            aspectElements = self.getElementsByType (self.ASPECT)
            for aspect in aspectElements:
                pointcuts = aspect.getTargetEdges (self.graph)
                for pointcut in pointcuts:
                    aspectTarget = pointcut.getTarget ()
                    aspect = self.getElement (pointcut.getSource ())
                    pointcutElement = self.getElement (pointcut.getId ())
                    pointcutElement.set (self.ASPECT, aspect.getLabel ())
                    logging.debug ("ast:register-aspect: (%s) %s", pointcutElement.getLabel (), pointcutElement.getType ())
                    self.compilerContext.aspects.append (pointcutElement)                

            ''' weave aspects
            self.ast_weaveAspects ()
            '''
            
            ''' register jobs and daxes '''
            seenJobs = [] # todo: understand why there are duplicates in the first place 
            for elementType in [ self.JOB, self.DAX ]:
                elements = self.getElementsByType (elementType)
                for element in elements:
                    if not element.getLabel () in seenJobs:
                        seenJobs.append (element.getLabel ())
                        logging.debug ("ast:map-nodes: register job: %s", element.getLabel ())
                        jobs.append (element)

            self.ast_buildSubWorkflows (jobs)
        return jobs

    ''' Build Sub Workflows: Compile each sub-workflow object. '''
    def ast_buildSubWorkflows (self, jobs):
        ''' build sub workflows '''
        elements = self.getElementsByType (self.WORKFLOW)
        for element in elements:
            if not element.getLabel () in self.compilerContext.processedWorkflows:
                logging.debug ("ast:map-nodes: register workflow: %s %s", element.getLabel (), self.compilerId)
                self.compilerContext.processedWorkflows.append (element.getLabel ())
                jobs.append (element)
                args = element.get (self.ATTR_ARGS)
                if not args:
                    args = self.getExecuteArguments ()
                    logging.debug ("ast:map-nodes: set workflow args %s: %s", element.getLabel (), args)
                    element.set (self.ATTR_ARGS, args)
                    self.ast_compileWorkflow (element)

    ''' Map edges. Add all graph edges to the object map if theyre not already there. '''
    def ast_mapEdges (self):
        logging.debug ("ast:map-edges: cid=%s", self.compilerId)		
        edgeElements = []
        edges = self.graph.getEdges ()
        for edge in edges:
            element = self.getElement (edge.getId ())
            if not element:
                element = self.ast_mapEdge (edge)
            edgeElements.append (element)
        return edgeElements

    ''' Add an edge to the object map. '''
    def ast_mapEdge (self, edge):
        element = ASTElement (edge)
        logging.debug ("ast:map-edge (%s)->(%s)", edge.getSource(), edge.getTarget ())
        self.addElement (edge.getId (), element)
        return element
    
    ''' Dereference: lookup concrete objects and alter the graph to remove references. '''
    def ast_dereference (self):
        logging.debug ("ast:dereference: cid=%s", self.compilerId)
        nodes = self.graph.getNodes ()
        for node in nodes:
            refId = node.getId ()
            element = self.getElement (node.getId ())
            if element:
                nodeId = element.getId ()
                if refId != nodeId: 
                    ''' node is a reference '''
                    edges = self.graph.getEdges ()
                    for edge in edges:
                        if edge.getTarget () == refId:
                            ''' for every edge pointing to the reference '''
                            edge.setTarget (nodeId)
                        if edge.getSource () == refId:
                            ''' for every edge from the reference '''
                            edge.setSource (nodeId)

    ''' Inherit: propagate properties from base to derived objects. '''
    def ast_inherit (self):
        logging.debug ("ast:inheritance: cid=%s", self.compilerId)
        abstractElements = self.getElementsByType (self.ABSTRACT)
        for abstractElement in abstractElements:
            isRoot = True
            origins = abstractElement.getOrigins (self.graph)
            for origin in origins:
                originElement = self.getElement (origin)
                #if originElement.getType () == self.ABSTRACT:
                if originElement and originElement.getType () == self.ABSTRACT:
                    isRoot = False
                    break
            if isRoot:
                self.ast_effectInheritance (abstractElement)

    ''' Effect Inheritance: Add inherited characteristics to targeted nodes. '''
    def ast_effectInheritance (self, abstractElement, tab=""):        
        logging.debug ("%sast:inherit:%s", tab, abstractElement.getLabel ())
        targets = abstractElement.getTargets (self.graph)
        for targetId in targets:
            target = self.getElement (targetId)
            if target:
                logging.debug ("%sast:inherit:target: parent=(id=%s,label=%s) target=(id=%s,origid=%s,label=%s)",
                               tab, abstractElement.getId (), abstractElement.getLabel (), target.getId (), targetId, target.getLabel ())
                logging.debug ("target type: %s", target.getType ())
                target.addAncestor (abstractElement)
                if target.getType () == self.ABSTRACT:
                    self.ast_effectInheritance (target, "%s%s" % (tab, "    "))
            else:
                logging.error ("unable to find target element (%s) of abstract element (%s)", targetId, abstractElement.getLabel ())

    def ast_processEdgeOperators (self, edgeElements):
        result = []
        for edge in edgeElements:
            deleteOperator = edge.get ("deleteWhenSource")
            logging.debug ("ast:edge-op: get delete operator: %s", deleteOperator)
            if deleteOperator:
                source = self.getElement (edge.getNode().getSource ())
                match = re.match (deleteOperator, source.getLabel ())
                if not match:
                    logging.debug ("ast:edge-ops: %s did not match delete operator [%s]", source.getLabel (), deleteOperator)
                    result.append (edge)
                else:
                    logging.debug ("ast:edge-ops: %s matched delete operator [%s]", source.getLabel (), deleteOperator)
            else:
                result.append (edge)
        return result

    ''' build the abstract syntax tree '''
    def buildAST (self):
        logging.debug ("ast:build-abstractsyntax: cid=%s", self.compilerId)
        self.ast_mapEdges ()
        jobs = self.ast_mapNodes ()
        if not self.isContextModel ():
            self.validateGraph ()
            edgeElements = self.ast_processEdgeOperators (self.ast_mapEdges ())
            self.ast_dereference ()
            self.ast_inherit ()
            daxContext = self.ast_analyzeJobs (jobs, edgeElements)
            self.ast_createDependencies (daxContext)
            self.reportErrors ()

    ''' Analyze Jobs: Grok inputs and outputs of each job, constructing a process model. '''
    def ast_analyzeJobs (self, jobs, edgeElements):
        daxContext = ASTContext ()
        for job in jobs:
            jobId = job.getNode().getId ()
            jobLabel = job.getNode().getLabel ()
            logging.debug ("ast-analyze-job: job=%s, id=%s, cid=%s", jobLabel, jobId, self.compilerId)
            jobContext = JobContext (job, self.namespace, self.version)
            for edge in edgeElements:
                edgeTarget = edge.getNode().getTarget ()
                source = self.getElement (edge.getNode().getSource ())
                ''' an output file can be the target end of an edge from a job '''
                if edge.getNode().getSource () == jobId and edge.get (self.ATTR_TYPE) == self.OUTPUT:
                    fileElement = self.getElement (edgeTarget)
                    self.addOutputFile (jobContext, fileElement, edge)
                    logging.debug ("add-job-output: (cid=%s) job (%s) outputs (%s)", self.compilerId, job.getLabel (), fileElement.getLabel ())
                elif edgeTarget == jobId and source:
                    logging.debug ("add-job-edge: source(%s,%s)-edge(%s)->target(%s,%s)",
                                   source.getId (), source.getLabel (), edge.getId (), job.getId (), job.getLabel ())
                    # some file, executable or other modifier to a job.
                    sourceType = source.getType ()
                    # an executable can be the source end of an edge to a job  
                    if sourceType == self.EXECUTABLE:
                        self.addExecutable (jobContext, source)
                    # an abstract job can be the source end of an edge to a job 
                    elif sourceType == self.JOB or sourceType == self.WORKFLOW or sourceType == self.DAX:
                        jobContext.addOrigin (source.getId ())
                        logging.debug ("job-dependency: %s is origin of %s (cid=%s)", source.getLabel (), job.getLabel (), self.compilerId)
                    # an input file can be the source end of an edge to a job 
                    elif edge.getType () == self.INPUT:
                        self.addInputFile (jobContext, source, edge)
                    else:
                        logging.error ("job %s is targeted by unrecognized node %s (%s) (cid=%s)", job.getLabel (), source.getLabel(), source.getType (), self.compilerId)
            self.ast_translateToOutputModel (jobContext, daxContext)
        return daxContext

    ''' Translate To Output Model: Write a job into the workflow management systems workflow model. '''
    def ast_translateToOutputModel (self, jobContext, daxContext):
        job = jobContext.getJob ()
        jobId = job.getId ()
        abstractJob = None
        testJob = jobContext.getTestJob ()
        jobType = job.getType ()
        logging.debug ("job (%s) type is (%s)", job.getLabel (), job.getType ())
        if jobType == self.WORKFLOW or jobType == self.DAX:
            logging.debug ("emitter:add-workflow-job: %s", job.getLabel ())
            abstractJob = self.workflowModel.addSubWorkflow (self.formWorkflowName (job))
            if jobId in self.compilerId:
                testJob = ASTTestJob (jobLabel,
                                      self.WORKFLOW, 
                                      self.workflowCompiler[jobId] )
                jobContext.setTestJob (testJob)
            else:
                logging.debug ("emitter:add-workflow:test: Unable to create test job for workflow: %s", job.getLabel ())
        elif jobType == self.JOB:
            logging.debug ("emitter:add-job: %s", job.getLabel ())
            abstractJob = self.workflowModel.addJob (job.getId ())
        if abstractJob:
            job.setDaxNode (abstractJob)
            self.workflowModel.addProfiles (abstractJob, job.getProfiles ())
            self.workflowModel.addInputFiles (abstractJob, jobContext.inFiles)
            self.workflowModel.addOutputFiles (abstractJob, jobContext.outFiles)
            args = job.get (self.ATTR_ARGS)
            if type (args) == list:
                args = " ".join (args)
            if args:
                allFiles = copy (jobContext.inFiles)
                allFiles.update (jobContext.outFiles)
                eachArg = args.split (" ")
                for arg in eachArg:
                    if arg in allFiles:
                        logging.debug ("emitter:replace-filename: %s", arg) 
                        self.workflowModel.addArguments (abstractJob, allFiles [arg][0].getDaxNode ())
                        if testJob:
                            testJob.addArguments ([ "%s/%s" % (os.getcwd (), arg) ])
                    else:
                        self.workflowModel.addArguments (abstractJob, arg)
                        if testJob:
                            testJob.addArguments ([ arg ])
            daxContext.addWmsJob (jobId, abstractJob)
            daxContext.setDependencies (jobId, jobContext.getOrigins ())
            self.testJobs[jobId] = testJob
        return daxContext

    ''' Write compiler output for this compiler instances workflow model to the provided stream. '''
    def writeDAX (self, stream=sys.stdout):
        if len(self.errorMessages) == 0 and not self.isPackaging ():
            logging.debug ("compiler:write-output: cid=%s", self.compilerId)
            self.workflowModel.writeExecutable (stream)
            
    ''' Get arguments to execute this workflow on the configured workflow management system. '''
    def getExecuteArguments (self, workflow=None, other=[]):
        return self.getWorkflowManagementSystem().getExecuteArguments (self.getSites (),
                                                                       workflow,
                                                                       other)
    ''' Test the workflow. '''
    def executeTest (self):
        cwd = os.getcwd ()        
        targetDir = "target"
        if self.clean:
            shutil.rmtree (targetDir, True)
            time.sleep (0.5)
        if not os.path.exists (targetDir):
            os.makedirs (targetDir)
        os.chdir (targetDir)
        testProperties = self.getProperty ("testProperties")
        if not testProperties:
            testProperties = {}
        testProperties[self.APP_HOME] = self.appHome.replace ("\\", "/")
        executor = Executor (testProperties)      
        level = self.logManager.setLogLevel ("info")
        for root in self.roots:
            logging.debug ("=== T E S T I N G   W O R K F L O W === : cwd [%s]", os.getcwd ())
            testJob = self.testJobs [root]
            if testJob:
                try:
                    self.executeTestLevel ([ testJob ], executor)
                except ValueError:
                    errorMessage = sys.exc_info()[1]
                    logging.error ("[%s] executing testJob: %s", errorMessage, testJob.getName ())                
                    sys.exit (1)
        self.logManager.setLogLevel (level)

    ''' Execute a level of tests. '''
    def executeTestLevel (self, level, executor):
        levels = []
        for test in level:
            test.execute (executor)
            levels.append (test.getChildren ())
        for nextLevel in levels:
            self.executeTestLevel (nextLevel, executor)

    ''' Generate workflow management system specific catalogs. '''
    def generateCatalogs (self, write=True):
        site = self.getProperty ("site")
        if site:
            ''' site catalog '''
            clusterId = site ["CLUSTER_ID"]
            self.setSites (",".join ([ self.getSites (), clusterId ]))

            logging.debug ("ast:add-site: %s", self.getSites ())
            self.getSiteCatalog ().addEntry (
                site ["CLUSTER_ID"],
                {
                "siteName"                     : clusterId,
                "hostName"                     : site ["CLUSTER_HOSTNAME"],
                "scheduler"                    : site ["CLUSTER_SCHEDULER"],
                "schedulerType"                : "unknown",
                "scratchFileServerProtocol"    : "gsiftp",
                "scratchFileServerURL"         : "gsiftp://%s" % site ["CLUSTER_HOSTNAME"],
                "scratchFileServerMountPoint"  : site ["CLUSTER_WORK_DIR"],
                "scratchInternalMountPoint"    : site ["CLUSTER_WORK_DIR"],
                "storageFileServerProtocol"    : "gsiftp",
                "storageFileServerMountPoint"  : site ["CLUSTER_WORK_DIR"],
                "storageMountPoint"            : site ["CLUSTER_HOSTNAME"],
                "storageInternalMountPoint"    : site ["CLUSTER_WORK_DIR"],
                "pegasusLocation"              : site ["CLUSTER_PEGASUS_HOME"],
                "globusLocation"               : site ["CLUSTER_GLOBUS_LOCATION"]
                })
        if write:
            self.writeMetaDataCatalogs ()

    def getContextualizedModels (self):
        allModels = self.getAllModelPaths ()
        contextualizedMap = {}
        for model in allModels:
            logging.debug ("   contextualizing model: %s", model)
            logicalName = os.path.realpath (model)
            tempLogicalName = logicalName
            modelPath = self.getModelPath ()
            last = None
            for element in modelPath:
                element = os.path.realpath (element)
                logging.debug ("last: %s, element: %s, logical: %s", last, element, logicalName)
                if not last or len(last) < len(element):
                    if logicalName.startswith (element):
                        tempLogicalName = logicalName.replace (element, "")
                        logging.debug ("       temp logical: %s", tempLogicalName)
                        last = element
            contextualizedMap [tempLogicalName] = model
        return contextualizedMap

    ''' map model relationships '''
    def mapModelRelationships (self):
        self.ast_mapNodes ()
        compilerId = self.compilerId
        elements = self.getElementsByType (self.WORKFLOW)
        seen = []
        for element in elements:
            if not element.getLabel () in seen:
                seen.append (element.getLabel ())
                logging.debug ("ast:map-model-relationships: register job: %s", element.getLabel ())
                self.ast_compileWorkflow (element)
        self.compilerId = compilerId

    ''' analyze a model and package all artifacts into a portable archive. '''
    def package (self, additionalFiles):

        ''' map '''
        self.mapModelRelationships ()
            
        self.generateCatalogs (write=False)        

        logging.debug ("myid: %s %s", self.compilerId, self.getSites ())

        outputArchive = os.path.basename (self.compilerId)
        outputArchive = outputArchive.replace (".graphml", ".grayson")
        outputArchive = os.path.join (self.getOutputDir (), outputArchive)

        contextualizedMap = self.getContextualizedModels ()

        ''' write context info '''
        conf = {
            self.CONF_INPUT_PROPERTIES : self.getInputModelProperties (),
            self.CONF_OUTPUT_FILE : self.output,
            self.CONF_SITES : self.getSites ()
            }
        GraysonUtil.writeFile (self.CONF_FILE, json.dumps (conf, indent=4))
        contextualizedMap [self.CONF_FILE] = os.path.join (".", self.CONF_FILE)

        GraysonUtil.listDirs (additionalFiles, contextualizedMap)

        ''' package '''
        GraysonPackager.package (patterns = contextualizedMap,
                                 output_file = outputArchive,
                                 relativeTo = os.getcwd ())
        ''' verify package '''
        GraysonPackager.verify (input_file = outputArchive)


    ''' unpack an archive '''
    def unpack (self, archive, outputdir):
        unpackdir = os.path.join (outputdir, "%s.tmp" % archive)
        unpackdir = os.path.join (outputdir)

        ''' verify package '''
        GraysonPackager.verify (input_file = archive)
        ''' unpack '''
        GraysonPackager.unpack (input_file = archive, output_dir = unpackdir)


        bin = os.path.join (unpackdir, "bin")
        if os.path.isdir (bin):
            os.system ("chmod +x %s/*" % bin)
            logging.debug ("chmodding bin")

        logging.debug ("unpacked archive: %s", archive)
        ''' load the config object '''
        confFile = os.path.join (unpackdir, self.CONF_FILE)
        if os.path.exists (confFile):
            data = GraysonUtil.readFile (confFile)
            config = json.loads (data)
            logging.debug ("compiler:unpack:load-conf: (%s)", config)
            if self.CONF_INPUT_PROPERTIES in config:
                self.setInputModelProperties (config [self.CONF_INPUT_PROPERTIES])
                logging.debug ("grayson:conf:set-input model properties: %s", self.getInputModelProperties ())
            if self.CONF_OUTPUT_FILE in config:
                self.output = config [self.CONF_OUTPUT_FILE]
                logging.debug ("grayson:conf:set-output: %s", self.output)
            if self.CONF_SITES in config:
                self.setSites (config [self.CONF_SITES])
                logging.debug ("grayson:conf:set-sites: %s", self.output)
        else:
            raise GraysonCompilerException ("%s is not a correctly formatted grayson archive.")

        baseModelName = os.path.basename (archive).replace (".grayson", ".graphml")
        match = re.search (".*(_[0-9]+).graphml", baseModelName)
        if match:
            baseModelName = baseModelName.replace (match.group (1), "")
            logging.debug ("grayson:base-model-name: %s", baseModelName)
        return (unpackdir, os.path.join (unpackdir, baseModelName))

    ''' Compile the given input models to create an executable workflow. '''
    @staticmethod
    def compile (models=[],
                 output=sys.stdout,
                 modelPath=None, #[".","model"],
                 namespace="app",
                 version="1.0",
                 logLevel=None,
                 logDir=None,
                 appHome=None,
                 test=False,
                 clean=False,
                 outputdir=".",
                 modelProperties={},
                 execute=False,
                 sites="local",
                 toLogFile=None,
                 packaging=False,
                 packagingAdditionalFiles = [],
                 plugin=CompilerPlugin ()):
        
        ''' initialize output directory '''
        if not os.path.exists (outputdir):
            os.makedirs (outputdir)
        if not appHome:
            appHome = os.getcwd ()

        ''' initialize logging '''
        logManager = LogManager.getInstance (logLevel, logDir, toFile=toLogFile)

        ''' initialize compiler '''
        compiler = GraysonCompiler (namespace, version, logManager, test, clean, appHome)
        compiler.output = output
        if type(output) == file:
            compiler.output = "stdout"
        compiler.setOutputDir (outputdir)
        compiler.setSites (sites)        
        compiler.setPackaging (packaging)
        if modelProperties:
            compiler.setInputModelProperties (modelProperties)
        compiler.setCompilerPlugin (plugin)

        modelName = models [0]
        if not modelPath:
            modelPath = []

        ''' unpack if its an archive '''
        unpackdir = None
        if modelName.endswith (".grayson"):
            fileName = os.path.basename (modelName)
            (unpackdir, newName) = compiler.unpack (modelName, outputdir)

            compiler.appHome = unpackdir
            local = compiler.getWorkflowManagementSystem().getSiteCatalog().getEntry ("local")
            local ["scratchFileServerMountPoint"] = compiler.appHome
            local ["storageFileServerMountPoint"] = compiler.appHome

            models.remove (modelName)
            models.insert (0, newName)
            modelName = newName
            logging.debug ("adding unpack model path: %s", os.path.dirname (newName)) 
            modelPath.append (os.path.dirname (newName))

        ''' initialize model path '''
        if os.path.sep in modelName and not modelName.endswith (".grayson"):
            modelPath.append (os.path.dirname (modelName))
        if modelPath:
            compiler.setModelPath (modelPath)

        ''' load graphs, build abstract syntax and workflow model '''
        logging.info ("grayson:compiling: %s", models)
        compiler.parse (models)
        compiler.setTopModel (models [0])
        compiler.buildAST ()

        ''' write output workflow '''
        if not compiler.isContextModel () and not packaging:
            try:
                opened_output = False
                if isinstance (output, str):
                    output = open (os.path.join (outputdir, output), "w")
                    opened_output = True
                try:
                    ''' generate executables '''
                    compiler.writeDAX (output)

                    compiler.getCompilerPlugin().notifyWorkflowCreation (modelName, output, topWorkflow=True)
                finally:
                    if opened_output:
                        output.close ()
            except IOError:
                traceback.print_stack ()

        if packaging:

            ''' package '''
            compiler.package (packagingAdditionalFiles)

        else:
            ''' generate meta data catalogs '''
            compiler.generateCatalogs ()
            
            ''' execute the workflow '''
            if execute:
                workflowName = os.path.join (outputdir, compiler.output)
                compiler.getWorkflowManagementSystem().executeWorkflow (compiler.getSites (),
                                                                        workflowName,
                                                                        plugin)

        return compiler

if __name__ == '__main__':
    test_grayson_compiler ()



